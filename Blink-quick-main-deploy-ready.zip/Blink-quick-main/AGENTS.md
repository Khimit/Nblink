# QuickBlink - 10-Minute Quick Commerce Ecosystem Project Context

## Project Overview
QuickBlink is an end-to-end, production-grade 10-minute quick commerce platform modeled after Blinkit and Zepto. It connects local Kirana stores with nearby customers and gig delivery partners through four distinct, synchronized portals:

1. **Customer Grocery App** (`?view=customer` or `/`):
   - Category browser (Dairy, Vegetables, Snacks, Beverages, Staples), search & filter.
   - Cart management, address selector with landmark and 10-min ETA badge.
   - Instant UPI payment checkout (Google Pay & PhonePe simulation with transaction IDs and QR).
   - Live delivery tracking with order status steps, countdown timer, and secure 4-digit Delivery OTP.

2. **Partner Kirana Store OS** (`?view=shopkeeper`):
   - Audible incoming order buzzer and alerts.
   - Digital packing checklist (item-by-item tick system before bag sealing).
   - Inventory availability toggles (instant in-stock/out-of-stock switches).
   - Product management (add, edit price/stock, delete) and new store onboarding.
   - Daily store settlements, GMV counter, and order history.

3. **Delivery Partner Cockpit** (`?view=delivery`):
   - High-contrast rider interface with Online/Offline duty switch.
   - Live order pickup radar with store location and customer doorstep route navigation.
   - Anti-theft 4-digit OTP PIN verification: Rider must enter the customer's OTP to mark the order delivered.
   - Shift earnings tracker (₹45 base payout per drop + customer tips).

4. **Operations HQ Control Tower** (`?view=admin`):
   - Real-time citywide dispatch matrix, total GMV, commission counter, and active fleet tracker.
   - Store commission rate controller (default 5%).
   - Store activation toggles and emergency order cancellation controls.

5. **4-Screen Command Center** (`?multi=true`):
   - Side-by-side live quadrant view rendering Customer, Store, Rider, and Admin views together for full lifecycle testing.
   - ⚡ 1-Click Demo button to simulate the complete cycle automatically.

---

## Technical Stack & Architecture

- **Frontend**: React 18, Vite, TypeScript, Tailwind CSS, Lucide React icons.
- **Backend & Cloud Database**:
  - Firebase Firestore configured (`firebase-applet-config.json`, `firebase-blueprint.json`, `firestore.rules`).
  - Real-time Firestore document sync in `src/services/cloudSync.ts` (`orders` collection).
- **Audio Feedback**: Synthesized Web Audio chimes in `src/utils/audio.ts` (Store order bell, packing chime, rider dispatch alert, delivery success chime).
- **PWA & Mobile Ready**: Web App Manifest (`/manifest.json`), service worker (`/sw.js`), and install prompt hooks (`src/hooks/usePWAInstall.ts`, `InstallModal.tsx`).
- **Safety Constraints**:
  - Client-side code strictly avoids `process.env` (uses Vite's `import.meta.env`).
  - Safe sandboxed window execution for preview iframes.

---

## Key Files
- `src/App.tsx`: Main layout, role rendering, phone simulator, and 4-screen view switch.
- `src/context/AppContext.tsx`: Master state, local storage persistence, URL query param synchronization (`?view=...`), and Firestore hooks.
- `src/services/cloudSync.ts`: Real-time order listeners and Firestore writes.
- `src/components/Header.tsx`: Navigation bar, role tabs, Portals Hub, and simulator toggles.
- `src/components/AppPortalsModal.tsx`: Persona directory with direct shareable links.
- `src/components/MultiScreenView.tsx`: 4-quadrant simultaneous ecosystem cockpit.
- `src/components/Customer/`: Shopping catalog, cart drawer, checkout, and live order tracking.
- `src/components/Shopkeeper/`: Store inventory manager, order checklist, and incoming order buzzer.
- `src/components/Delivery/`: Rider duty cockpit, route map, and OTP delivery verification.
- `src/components/Admin/`: Metrics dashboard, store management, and commission settings.

---

## How to Continue Work in Future Turns
When continuing or extending this project:
1. Maintain the 4 distinct views (`customer`, `shopkeeper`, `delivery`, `admin`) and keep URL parameters synced.
2. Ensure any order mutations call `saveOrderToCloud` in `AppContext.tsx` so cross-device sync remains active.
3. For additional features, potential next steps include:
   - Migrating `shops` and `products` collections from localStorage to Firestore.
   - Integrating real Google Maps SDK directions.
   - Integrating Razorpay or cashfree UPI gateway webhooks.
