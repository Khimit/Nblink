# Real Razorpay Payments — What Changed & How to Set It Up

## ⚠️ Important: what was in this code before

The original checkout flow deep-linked to GPay/PhonePe with a **hardcoded
personal UPI ID (`khimitjangale-1@oksbi`)** baked into the code, and marked
every order "paid" the moment the customer clicked "I Have Paid" — with
zero actual verification. In practice this meant:

- Real money from any customer who used it would have gone to a stranger's
  personal bank account, not yours.
- The app would mark an order "paid" and dispatch it even if the customer
  paid nothing at all, or paid nothing to you.

This has been removed. It's replaced with a proper Razorpay integration
where payment is only ever confirmed after your own server verifies a
cryptographic signature from Razorpay — the customer's word is never
trusted on its own.

## How the new flow works

1. Customer taps "Pay Now" → frontend asks **your server** (`server.js`)
   to create a Razorpay order.
2. Razorpay's official Checkout widget opens (real UPI/card/netbanking).
3. After payment, Razorpay gives the frontend a signature.
4. The frontend sends that signature to **your server**, which recomputes
   it using your secret key and confirms it matches.
5. Only if it matches does the order get created and marked "paid".

Your Razorpay **secret key never leaves the server** — it's not in any
file the browser downloads.

## Setup steps

1. **Get test keys instantly (no business KYC required for testing):**
   - Sign up at [razorpay.com](https://razorpay.com)
   - Go to Settings → API Keys → Generate Test Key
   - Copy the Key ID and Key Secret

2. **Configure your environment:**
   ```bash
   cp .env.example .env
   ```
   Then fill in:
   ```
   RAZORPAY_KEY_ID="rzp_test_..."
   RAZORPAY_KEY_SECRET="..."
   ```

3. **Install the new dependencies:**
   ```bash
   npm install
   ```

4. **Run both the app and the payment server together:**
   ```bash
   npm run dev
   ```
   This starts Vite (port 3000) and the payment server (port 8787) side
   by side. The frontend automatically proxies `/api/*` calls to the
   payment server.

5. **Test with Razorpay's test cards / test UPI:**
   - Test card: `4111 1111 1111 1111`, any future expiry, any CVV
   - Test UPI: `success@razorpay` (always succeeds), `failure@razorpay`
     (always fails) — useful for testing your error handling

## Going live with real money

1. Complete Razorpay's business KYC (PAN, bank account, business proof) —
   this is Razorpay's process, not something that can be skipped.
2. Once approved, generate **Live** keys and replace the test keys in
   your production `.env`.
3. Deploy `server.js` somewhere it can run continuously (Render, Railway,
   a small VPS, Cloud Run, etc.) — it can't live only on your laptop.
4. Point your deployed frontend's `/api` calls at that server's real URL
   instead of `localhost:8787` (update the Vite proxy or, in production,
   serve both from behind the same domain).

## Also worth doing before real launch

- Add a Razorpay **webhook** endpoint as a second, server-to-server
  confirmation path — the current setup verifies via the browser
  callback, which is fine for launch but a webhook adds resilience if a
  customer closes the browser mid-payment.
- Log payment attempts and failures somewhere durable (not just
  `console.log`) so you can investigate disputes.
