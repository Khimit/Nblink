// Minimal payment backend for QuickBlink.
//
// This exists because Razorpay (like every real payment gateway) requires
// your secret API key to create orders and verify payment signatures.
// That secret must NEVER be shipped to the browser — so this tiny server
// is the only place it's used.
//
// Run it alongside the Vite dev server:
//   npm run server
// (or `npm run dev` to run both together, see package.json)

import express from 'express';
import Razorpay from 'razorpay';
import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

const requiredEnvVars = ['RAZORPAY_KEY_ID', 'RAZORPAY_KEY_SECRET'];
const missing = requiredEnvVars.filter((v) => !process.env[v]);
if (missing.length) {
  console.warn(
    `⚠️  Missing env vars: ${missing.join(', ')}. Copy .env.example to .env and add your Razorpay TEST keys from https://dashboard.razorpay.com/app/keys`
  );
}

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

const app = express();
app.use(express.json());

// Step 1: Frontend asks us to create an order before opening Razorpay Checkout.
app.post('/api/payment/create-order', async (req, res) => {
  try {
    const { amount, receipt } = req.body;
    if (!amount || typeof amount !== 'number' || amount <= 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }

    const order = await razorpay.orders.create({
      amount: Math.round(amount * 100), // Razorpay expects paise, not rupees
      currency: 'INR',
      receipt: receipt || `receipt_${Date.now()}`
    });

    res.json({
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId: process.env.RAZORPAY_KEY_ID // public key id — safe to expose
    });
  } catch (err) {
    console.error('Razorpay order create error:', err);
    res.status(500).json({ error: 'Failed to create payment order' });
  }
});

// Step 2: After the customer pays, verify the cryptographic signature
// Razorpay sends back. Only if this matches do we trust the payment.
app.post('/api/payment/verify', (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({ verified: false, error: 'Missing fields' });
  }

  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  const verified = expectedSignature === razorpay_signature;
  if (!verified) {
    console.warn('Payment signature mismatch — possible tampering attempt:', {
      razorpay_order_id,
      razorpay_payment_id
    });
  }

  res.json({ verified });
});

const PORT = process.env.PORT || 8787;
app.listen(PORT, () => {
  console.log(`💳 Payment server running on http://localhost:${PORT}`);
});
