# Deploying QuickBlink for Live Testing

GitHub Pages alone can't run this app fully — it only serves static files,
and your payment backend needs an actual server process to keep your
Razorpay secret key safe. **Vercel** solves this: it deploys straight from
GitHub, serves your frontend, AND runs `/api/payment/*` as serverless
functions automatically. It also gives you free HTTPS, which the live GPS
tracking requires when testing on a real phone.

## Step 1 — Push this project to GitHub

If you don't already have a repo:

```bash
cd Blink-quick-main
git init
git add .
git commit -m "Real payments + live GPS tracking"
```

Create a new empty repo on [github.com/new](https://github.com/new), then:

```bash
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git branch -M main
git push -u origin main
```

**Important:** make sure `.env` is in `.gitignore` before you push (it
should already be — double check) so your Razorpay secret key never ends
up on GitHub.

## Step 2 — Deploy to Vercel

1. Go to [vercel.com](https://vercel.com) and sign up/log in with your
   GitHub account.
2. Click **"Add New → Project"**, select your repo, click **Import**.
3. Vercel will auto-detect the Vite build — leave the defaults.
4. Before deploying, click **Environment Variables** and add:
   - `RAZORPAY_KEY_ID` = your test key ID
   - `RAZORPAY_KEY_SECRET` = your test key secret
5. Click **Deploy**. In about a minute you'll get a live URL like:
   `https://your-repo-name.vercel.app`

That's it — this single URL serves the app AND the payment API.

## Step 3 — Test it live

- Open the Vercel URL on your **laptop** and your **phone** at the same
  time (different tabs/devices).
- Try `?multi=true` on the URL for the 4-screen command center, or
  `?view=customer`, `?view=shopkeeper`, `?view=delivery`, `?view=admin`
  in separate tabs/devices to play different roles simultaneously.
- Place an order as Customer with a real Razorpay test payment
  (`success@razorpay` UPI or card `4111 1111 1111 1111`).
- Accept it as Shopkeeper, pack it, then switch to Delivery on your
  **phone** specifically (it needs to be the device with GPS) and accept
  the delivery — allow location access when prompted.
- Watch the Customer's tracking screen (on your laptop) show your phone's
  real live position moving on the map.

## Step 4 — Share it with testers

Since it's a real public URL now, you can just send that Vercel link to
friends, co-founders, or early testers — no install required, and it
installs as a PWA ("Add to Home Screen") for an app-like feel.

## Every time you push new changes

Vercel automatically redeploys whenever you `git push` to `main` — no
extra steps needed after the first setup.

## Note on the shared AI Studio Firebase project

This still uses the Firebase project that was auto-provisioned when this
app was originally generated, not one you own. That's fine for testing
with friends, but before real customers use it, move to your own Firebase
project (Firestore console → create project → replace
`firebase-applet-config.json`) so you control billing, quotas, and data
ownership.
