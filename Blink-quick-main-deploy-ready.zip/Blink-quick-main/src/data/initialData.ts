import { Shop, Product, DeliveryPartner, Order, Coupon } from '../types';

export const INITIAL_SHOPS: Shop[] = [
  {
    id: 'shop-1',
    name: 'Sharma Super Kirana & Fresh',
    ownerName: 'Ramesh Sharma',
    phone: '+91 98765 43210',
    upiId: 'sharmakirana@examplebank',
    address: 'Shop 14, Main Green Glen Market, Outer Ring Road',
    area: 'Bellandur, Bengaluru',
    distanceKm: 0.8,
    lat: 12.9279,
    lng: 77.6271,
    rating: 4.8,
    totalOrders: 1420,
    isOpen: true,
    commissionPercent: 5,
    bannerUrl: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=800&auto=format&fit=crop&q=80',
    categories: ['Dairy & Bread', 'Fresh Veggies', 'Snacks & Munchies', 'Instant Foods', 'Drinks & Juices', 'Daily Staples']
  },
  {
    id: 'shop-2',
    name: 'Sri Balaji Daily Needs & Organics',
    ownerName: 'Venkatesh Rao',
    phone: '+91 98450 11223',
    upiId: 'sribalajidaily@examplebank',
    address: 'Plot 22, 1st Cross, HSR Layout Sector 2',
    area: 'HSR Layout, Bengaluru',
    distanceKm: 1.6,
    lat: 12.9116,
    lng: 77.6474,
    rating: 4.9,
    totalOrders: 980,
    isOpen: true,
    commissionPercent: 5,
    bannerUrl: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80',
    categories: ['Dairy & Bread', 'Fresh Veggies', 'Snacks & Munchies', 'Daily Staples', 'Household Care']
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  // Dairy & Bread
  {
    id: 'p-1',
    shopId: 'shop-1',
    name: 'Amul Taaza Fresh Toned Milk',
    category: 'Dairy & Bread',
    brand: 'Amul',
    unit: '500 ml',
    mrp: 28,
    price: 27,
    discountPercent: 4,
    inStock: true,
    stockCount: 45,
    imageUrl: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=500&auto=format&fit=crop&q=80',
    description: 'Pasteurized toned milk with minimum 3.0% fat and 8.5% SNF. Wholesome and fresh.'
  },
  {
    id: 'p-2',
    shopId: 'shop-1',
    name: 'Britannia 100% Whole Wheat Brown Bread',
    category: 'Dairy & Bread',
    brand: 'Britannia',
    unit: '400 g',
    mrp: 55,
    price: 49,
    discountPercent: 11,
    inStock: true,
    stockCount: 22,
    imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=500&auto=format&fit=crop&q=80',
    description: 'Baked to golden perfection with 100% whole wheat grains. Rich in dietary fiber.'
  },
  {
    id: 'p-3',
    shopId: 'shop-1',
    name: 'Amul Pasteurized Butter',
    category: 'Dairy & Bread',
    brand: 'Amul',
    unit: '100 g',
    mrp: 60,
    price: 58,
    discountPercent: 3,
    inStock: true,
    stockCount: 30,
    imageUrl: 'https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=500&auto=format&fit=crop&q=80',
    description: 'Utterly butterly delicious butter made from pure fresh cow and buffalo milk.'
  },
  {
    id: 'p-4',
    shopId: 'shop-1',
    name: 'Mother Dairy Classic Malai Paneer',
    category: 'Dairy & Bread',
    brand: 'Mother Dairy',
    unit: '200 g',
    mrp: 95,
    price: 88,
    discountPercent: 7,
    inStock: true,
    stockCount: 18,
    imageUrl: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=500&auto=format&fit=crop&q=80',
    description: 'Fresh and tender cottage cheese cubes, rich in natural dairy protein.'
  },

  // Fresh Veggies & Fruits
  {
    id: 'p-5',
    shopId: 'shop-1',
    name: 'Fresh Farm Red Tomatoes (Hybrid)',
    category: 'Fresh Veggies',
    brand: 'Farm Fresh',
    unit: '1 kg',
    mrp: 45,
    price: 34,
    discountPercent: 24,
    inStock: true,
    stockCount: 60,
    imageUrl: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=500&auto=format&fit=crop&q=80',
    description: 'Firm, juicy, and ripe farm-picked tomatoes ideal for gravies and salads.'
  },
  {
    id: 'p-6',
    shopId: 'shop-1',
    name: 'Golden Baby Potatoes (Aloo)',
    category: 'Fresh Veggies',
    brand: 'Farm Fresh',
    unit: '1 kg',
    mrp: 38,
    price: 28,
    discountPercent: 26,
    inStock: true,
    stockCount: 80,
    imageUrl: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=500&auto=format&fit=crop&q=80',
    description: 'Cleaned earthy potatoes, essential for everyday curries, parathas, and fries.'
  },
  {
    id: 'p-7',
    shopId: 'shop-1',
    name: 'Fresh Red Onions (Pyaz)',
    category: 'Fresh Veggies',
    brand: 'Farm Fresh',
    unit: '1 kg',
    mrp: 50,
    price: 39,
    discountPercent: 22,
    inStock: true,
    stockCount: 75,
    imageUrl: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?w=500&auto=format&fit=crop&q=80',
    description: 'Pungent and crisp Nashik onions, perfectly cured for long shelf-life.'
  },
  {
    id: 'p-8',
    shopId: 'shop-1',
    name: 'Royal Gala Sweet Apples',
    category: 'Fresh Veggies',
    brand: 'Shimla Orchards',
    unit: '4 pcs (approx 600g)',
    mrp: 160,
    price: 135,
    discountPercent: 15,
    inStock: true,
    stockCount: 25,
    imageUrl: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=500&auto=format&fit=crop&q=80',
    description: 'Crisp, sweet, and aromatic handpicked fresh apples from Himachal Pradesh.'
  },

  // Snacks & Munchies
  {
    id: 'p-9',
    shopId: 'shop-1',
    name: "Lay's India's Magic Masala Potato Chips",
    category: 'Snacks & Munchies',
    brand: "Lay's",
    unit: '50 g',
    mrp: 20,
    price: 19,
    discountPercent: 5,
    inStock: true,
    stockCount: 50,
    imageUrl: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=500&auto=format&fit=crop&q=80',
    description: 'Crispy sliced potato chips tossed with a special blend of Indian spice mix.'
  },
  {
    id: 'p-10',
    shopId: 'shop-1',
    name: 'Haldiram Nagpur Aloo Bhujia Sev',
    category: 'Snacks & Munchies',
    brand: 'Haldiram',
    unit: '200 g',
    mrp: 65,
    price: 59,
    discountPercent: 9,
    inStock: true,
    stockCount: 40,
    imageUrl: 'https://images.unsplash.com/photo-1599490659213-e2b9527bd087?w=500&auto=format&fit=crop&q=80',
    description: 'Minty, spicy, and extra crunchy potato-gram flour extruded noodle snacks.'
  },
  {
    id: 'p-11',
    shopId: 'shop-1',
    name: 'Cadbury Dairy Milk Silk Chocolate',
    category: 'Snacks & Munchies',
    brand: 'Cadbury',
    unit: '150 g',
    mrp: 175,
    price: 155,
    discountPercent: 11,
    inStock: true,
    stockCount: 35,
    imageUrl: 'https://images.unsplash.com/photo-1548907040-4baa42d10919?w=500&auto=format&fit=crop&q=80',
    description: 'Silky smooth melt-in-mouth milk chocolate with premium cocoa butter.'
  },

  // Instant Foods
  {
    id: 'p-12',
    shopId: 'shop-1',
    name: 'Maggi 2-Minute Masala Instant Noodles',
    category: 'Instant Foods',
    brand: 'Nestle',
    unit: '4 Pack (280 g)',
    mrp: 56,
    price: 52,
    discountPercent: 7,
    inStock: true,
    stockCount: 65,
    imageUrl: 'https://images.unsplash.com/photo-1612927601601-6638404737ce?w=500&auto=format&fit=crop&q=80',
    description: 'Beloved instant noodles with iron fortification and authentic tastemaker spice blend.'
  },
  {
    id: 'p-13',
    shopId: 'shop-1',
    name: 'Knorr Classic Thick Mixed Vegetable Soup',
    category: 'Instant Foods',
    brand: 'Knorr',
    unit: '43 g',
    mrp: 40,
    price: 36,
    discountPercent: 10,
    inStock: true,
    stockCount: 28,
    imageUrl: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=500&auto=format&fit=crop&q=80',
    description: 'Hearty restaurant style soup made with real crunchy vegetables, ready in 3 mins.'
  },

  // Drinks & Juices
  {
    id: 'p-14',
    shopId: 'shop-1',
    name: 'Coca-Cola Zero Sugar Can',
    category: 'Drinks & Juices',
    brand: 'Coca-Cola',
    unit: '300 ml',
    mrp: 40,
    price: 38,
    discountPercent: 5,
    inStock: true,
    stockCount: 40,
    imageUrl: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&auto=format&fit=crop&q=80',
    description: 'Crisp, refreshing taste of classic Coca-Cola with zero sugar and zero calories.'
  },
  {
    id: 'p-15',
    shopId: 'shop-1',
    name: 'Paper Boat Tender Coconut Water',
    category: 'Drinks & Juices',
    brand: 'Paper Boat',
    unit: '200 ml',
    mrp: 50,
    price: 45,
    discountPercent: 10,
    inStock: true,
    stockCount: 30,
    imageUrl: 'https://images.unsplash.com/photo-1525385133512-2f3bdd039054?w=500&auto=format&fit=crop&q=80',
    description: '100% natural, refreshing coconut water packed with electrolytes.'
  },

  // Daily Staples
  {
    id: 'p-16',
    shopId: 'shop-1',
    name: 'Aashirvaad Superior MP Shudh Chakki Atta',
    category: 'Daily Staples',
    brand: 'Aashirvaad',
    unit: '5 kg',
    mrp: 295,
    price: 255,
    discountPercent: 14,
    inStock: true,
    stockCount: 20,
    imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=500&auto=format&fit=crop&q=80',
    description: '100% pure whole wheat flour processed with traditional 4-step chakki grinding.'
  },
  {
    id: 'p-17',
    shopId: 'shop-1',
    name: 'Tata Salt Vaccum Evaporated Iodized Salt',
    category: 'Daily Staples',
    brand: 'Tata',
    unit: '1 kg',
    mrp: 28,
    price: 26,
    discountPercent: 7,
    inStock: true,
    stockCount: 50,
    imageUrl: 'https://images.unsplash.com/photo-1518110925495-5fe2fda0442c?w=500&auto=format&fit=crop&q=80',
    description: 'Desh Ka Namak with guaranteed iodine content for healthy family development.'
  },
  {
    id: 'p-18',
    shopId: 'shop-1',
    name: 'Fortune Sunlite Refined Sunflower Oil',
    category: 'Daily Staples',
    brand: 'Fortune',
    unit: '1 L Pouch',
    mrp: 145,
    price: 128,
    discountPercent: 12,
    inStock: true,
    stockCount: 24,
    imageUrl: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=500&auto=format&fit=crop&q=80',
    description: 'Light and healthy edible cooking oil enriched with Vitamins A, D, and E.'
  }
];

export const INITIAL_RIDERS: DeliveryPartner[] = [
  {
    id: 'rider-1',
    name: 'Rajesh Kumar',
    phone: '+91 97421 88990',
    vehicle: 'Ather 450X Electric Scooter',
    vehicleNumber: 'KA-01-EA-4921',
    rating: 4.9,
    photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    isOnline: true,
    todayEarnings: 580,
    completedDeliveries: 14
  },
  {
    id: 'rider-2',
    name: 'Amit Verma',
    phone: '+91 98860 33441',
    vehicle: 'Hero Splendor Plus',
    vehicleNumber: 'KA-05-MH-8219',
    rating: 4.8,
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    isOnline: true,
    todayEarnings: 420,
    completedDeliveries: 10
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-101',
    orderNumber: 'QB-88219',
    shopId: 'shop-1',
    shopName: 'Sharma Super Kirana & Fresh',
    shopPhone: '+91 98765 43210',
    shopAddress: 'Shop 14, Main Green Glen Market, Bellandur',
    customerName: 'Pooja Hegde',
    customerPhone: '+91 98451 99001',
    customerAddress: {
      flatNo: 'B-402, Sobha Iris',
      street: 'Green Glen Layout, Near Central Mall',
      landmark: 'Opposite Cult.Fit Gym',
      area: 'Bellandur',
      city: 'Bengaluru',
      pinCode: '560103',
      lat: 12.9308,
      lng: 77.6229
    },
    items: [
      {
        productId: 'p-1',
        name: 'Amul Taaza Fresh Toned Milk',
        unit: '500 ml',
        price: 27,
        quantity: 2,
        imageUrl: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=500&auto=format&fit=crop&q=80',
        isPacked: true
      },
      {
        productId: 'p-2',
        name: 'Britannia 100% Whole Wheat Brown Bread',
        unit: '400 g',
        price: 49,
        quantity: 1,
        imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=500&auto=format&fit=crop&q=80',
        isPacked: true
      },
      {
        productId: 'p-5',
        name: 'Fresh Farm Red Tomatoes (Hybrid)',
        unit: '1 kg',
        price: 34,
        quantity: 1,
        imageUrl: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=500&auto=format&fit=crop&q=80',
        isPacked: true
      }
    ],
    bill: {
      itemTotal: 137,
      deliveryFee: 0,
      handlingFee: 2,
      tip: 10,
      discount: 0,
      grandTotal: 149
    },
    payment: {
      method: 'gpay',
      upiId: 'pooja@okhdfcbank',
      status: 'paid',
      transactionId: 'UPI-7718290381',
      paidAt: 'Just now'
    },
    status: 'packing',
    otp: '4921',
    createdAt: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
    etaMinutes: 8,
    deliveryPartner: INITIAL_RIDERS[0],
    timeline: [
      {
        status: 'placed',
        title: 'Order Placed & Paid',
        timestamp: '5 mins ago',
        description: 'Payment of ₹149 received via Google Pay UPI'
      },
      {
        status: 'accepted',
        title: 'Sharma Super Kirana Accepted',
        timestamp: '4 mins ago',
        description: 'Store confirmed stock availability'
      },
      {
        status: 'packing',
        title: 'Order Being Packed',
        timestamp: '2 mins ago',
        description: 'Storekeeper Ramesh is packing your fresh items'
      }
    ]
  }
];

export const INITIAL_COUPONS: Coupon[] = [
  {
    id: 'coup-welcome50',
    code: 'WELCOME50',
    description: 'Flat ₹50 OFF on orders above ₹199',
    discountType: 'flat',
    discountValue: 50,
    minOrderAmount: 199,
    isActive: true,
    usageCount: 142,
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'coup-quick20',
    code: 'QUICK20',
    description: '20% OFF (up to ₹60) on orders above ₹149',
    discountType: 'percentage',
    discountValue: 20,
    minOrderAmount: 149,
    maxDiscount: 60,
    isActive: true,
    usageCount: 89,
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'coup-freedel',
    code: 'FREEDEL',
    description: 'Flat ₹25 OFF on delivery fee (min ₹99)',
    discountType: 'flat',
    discountValue: 25,
    minOrderAmount: 99,
    isActive: true,
    usageCount: 215,
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'coup-super100',
    code: 'SUPER100',
    description: 'Flat ₹100 OFF on mega cart above ₹399',
    discountType: 'flat',
    discountValue: 100,
    minOrderAmount: 399,
    isActive: true,
    usageCount: 47,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
  }
];

