export type Role = 'customer' | 'shopkeeper' | 'delivery' | 'admin';

export interface Shop {
  id: string;
  name: string;
  ownerName: string;
  phone: string;
  upiId: string;
  address: string;
  area: string;
  distanceKm: number;
  lat: number;
  lng: number;
  rating: number;
  totalOrders: number;
  isOpen: boolean;
  commissionPercent: number;
  bannerUrl: string;
  categories: string[];
}

export interface Product {
  id: string;
  shopId: string;
  name: string;
  category: string;
  brand: string;
  unit: string;
  mrp: number;
  price: number;
  discountPercent: number;
  inStock: boolean;
  stockCount: number;
  imageUrl: string;
  description: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type OrderStatus =
  | 'placed'
  | 'accepted'
  | 'packing'
  | 'packed'
  | 'assigned'
  | 'picked_up'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled';

export interface OrderItem {
  productId: string;
  name: string;
  unit: string;
  price: number;
  quantity: number;
  imageUrl: string;
  isPacked?: boolean;
}

export interface CustomerAddress {
  flatNo: string;
  street: string;
  landmark: string;
  area: string;
  city: string;
  pinCode: string;
  lat: number;
  lng: number;
}

export interface OrderBill {
  itemTotal: number;
  deliveryFee: number;
  handlingFee: number;
  tip: number;
  discount: number;
  grandTotal: number;
}

export interface PaymentDetails {
  method: 'razorpay' | 'gpay' | 'phonepe' | 'paytm' | 'upi_id' | 'cod';
  upiId?: string;
  status: 'paid' | 'pending';
  transactionId: string;
  paidAt: string;
}

export interface DeliveryPartner {
  id: string;
  name: string;
  phone: string;
  vehicle: string;
  vehicleNumber: string;
  rating: number;
  photo: string;
  isOnline: boolean;
  todayEarnings: number;
  completedDeliveries: number;
  activeOrderId?: string;
}

export interface Coupon {
  id: string;
  code: string;
  description: string;
  discountType: 'percentage' | 'flat';
  discountValue: number;
  minOrderAmount: number;
  maxDiscount?: number;
  isActive: boolean;
  usageCount?: number;
  createdAt?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  shopId: string;
  shopName: string;
  shopPhone: string;
  shopAddress: string;
  customerName: string;
  customerPhone: string;
  customerAddress: CustomerAddress;
  items: OrderItem[];
  bill: OrderBill;
  payment: PaymentDetails;
  couponCode?: string;
  status: OrderStatus;
  otp: string; // 4 digit delivery PIN e.g. "4921"
  createdAt: string;
  updatedAt: string;
  etaMinutes: number;
  deliveryPartner?: DeliveryPartner;
  // Live GPS position of the assigned rider, updated in real time from the
  // Delivery app's browser geolocation and synced via Firestore.
  riderLocation?: {
    lat: number;
    lng: number;
    updatedAt: string;
  };
  timeline: {
    status: OrderStatus;
    title: string;
    timestamp: string;
    description: string;
  }[];
}
