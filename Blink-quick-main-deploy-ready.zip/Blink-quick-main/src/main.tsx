import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Register Service Worker safely without blocking iframe execution
if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  try {
    // Only attempt registration in top-level windows outside restricted sandboxes
    if (window.self === window.top) {
      window.addEventListener('load', () => {
        try {
          navigator.serviceWorker
            .register('/sw.js')
            .catch(() => {});
        } catch {
          // Benign error in restricted iframe environments
        }
      });
    }
  } catch {
    // Ignore iframe permission issues
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);


