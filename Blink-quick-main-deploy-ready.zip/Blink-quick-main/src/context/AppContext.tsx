import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Shop,
  Product,
  Order,
  DeliveryPartner,
  CartItem,
  Role,
  OrderStatus,
  PaymentDetails,
  CustomerAddress,
  Coupon
} from '../types';
import {
  INITIAL_SHOPS,
  INITIAL_PRODUCTS,
  INITIAL_RIDERS,
  INITIAL_ORDERS,
  INITIAL_COUPONS
} from '../data/initialData';
import { soundEffects } from '../utils/audio';
import {
  saveOrderToCloud,
  listenToCloudOrders,
  updateOrderLocation,
  saveProductToCloud,
  deleteProductFromCloud,
  listenToCloudProducts,
  seedProductsToCloudIfEmpty,
  saveShopToCloud,
  listenToCloudShops,
  seedShopsToCloudIfEmpty,
  saveCouponToCloud,
  deleteCouponFromCloud,
  listenToCloudCoupons,
  seedCouponsToCloudIfEmpty
} from '../services/cloudSync';

interface AppContextType {
  role: Role;
  setRole: (role: Role) => void;
  isMobileSimulator: boolean;
  setIsMobileSimulator: (val: boolean) => void;
  isMultiScreenMode: boolean;
  setIsMultiScreenMode: (val: boolean) => void;
  activeShopId: string;
  setActiveShopId: (id: string) => void;
  activeRiderId: string;
  setActiveRiderId: (id: string) => void;

  // Data
  shops: Shop[];
  products: Product[];
  orders: Order[];
  riders: DeliveryPartner[];
  cart: CartItem[];

  // Coupon state & actions
  coupons: Coupon[];
  appliedCoupon: Coupon | null;
  applyCoupon: (code: string) => { success: boolean; message: string; discountAmount?: number };
  removeCoupon: () => void;
  addCoupon: (coupon: Omit<Coupon, 'id'>) => void;
  updateCoupon: (coupon: Coupon) => void;
  deleteCoupon: (id: string) => void;
  toggleCouponStatus: (id: string) => void;
  getCartDiscount: (specificCoupon?: Coupon | null) => number;

  // Customer actions
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  selectedAddress: CustomerAddress;
  setSelectedAddress: (addr: CustomerAddress) => void;
  placeOrder: (
    payment: { method: PaymentDetails['method']; upiId?: string; transactionId?: string },
    tip: number
  ) => Order;
  activeTrackingOrderId: string | null;
  setActiveTrackingOrderId: (id: string | null) => void;

  // Shopkeeper actions
  acceptOrder: (orderId: string) => void;
  toggleItemPacked: (orderId: string, productId: string) => void;
  markOrderPacked: (orderId: string) => void;
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (productId: string, updates: Partial<Product>) => void;
  deleteProduct: (productId: string) => void;
  updateShopSettings: (shopId: string, updates: Partial<Shop>) => void;
  onboardNewShop: (shop: Omit<Shop, 'id' | 'rating' | 'totalOrders'>) => void;

  // Rider actions
  acceptDeliveryTask: (orderId: string, riderId: string) => void;
  confirmPickup: (orderId: string) => void;
  verifyAndDeliver: (orderId: string, enteredOtp: string) => { success: boolean; message: string };
  toggleRiderDuty: (riderId: string) => void;
  updateRiderLocation: (orderId: string, lat: number, lng: number) => void;

  // Admin actions
  updateShopCommission: (shopId: string, commission: number) => void;
  toggleShopStatus: (shopId: string) => void;
  cancelOrder: (orderId: string, reason: string) => void;
  resetAllData: () => void;

  // Notifications & Interactive Demo
  notificationBanner: { message: string; role: Role; timestamp: number } | null;
  clearNotification: () => void;
  triggerLiveSimulation: () => void;
  isSimulating: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'quickblink_app_state_v1';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRoleState] = useState<Role>(() => {
    if (typeof window !== 'undefined') {
      try {
        const params = new URLSearchParams(window.location.search);
        const urlRole = params.get('view') || params.get('role');
        if (urlRole && ['customer', 'shopkeeper', 'delivery', 'admin'].includes(urlRole)) {
          return urlRole as Role;
        }
      } catch {
        // Fallback for sandboxed environments
      }
    }
    return 'customer';
  });

  const [isMobileSimulator, setIsMobileSimulator] = useState<boolean>(false);
  const [isMultiScreenMode, setIsMultiScreenMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      try {
        const params = new URLSearchParams(window.location.search);
        return params.get('multi') === 'true';
      } catch {
        return false;
      }
    }
    return false;
  });

  const setRole = (newRole: Role) => {
    setRoleState(newRole);
    if (typeof window !== 'undefined') {
      try {
        const url = new URL(window.location.href);
        url.searchParams.set('view', newRole);
        window.history.replaceState({}, '', url.toString());
      } catch {
        // Ignore iframe history security constraints
      }
    }
  };

  const [activeShopId, setActiveShopId] = useState<string>('shop-1');
  const [activeRiderId, setActiveRiderId] = useState<string>('rider-1');

  // Core State
  const [shops, setShops] = useState<Shop[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_shops`);
    return saved ? JSON.parse(saved) : INITIAL_SHOPS;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_products`);
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_orders`);
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [riders, setRiders] = useState<DeliveryPartner[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_riders`);
    return saved ? JSON.parse(saved) : INITIAL_RIDERS;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_cart`);
    return saved ? JSON.parse(saved) : [];
  });

  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_coupons`);
    return saved ? JSON.parse(saved) : INITIAL_COUPONS;
  });

  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);

  const [activeTrackingOrderId, setActiveTrackingOrderId] = useState<string | null>(() => {
    return orders.length > 0 ? orders[0].id : null;
  });

  const [selectedAddress, setSelectedAddress] = useState<CustomerAddress>({
    flatNo: 'B-402, Sobha Iris',
    street: 'Green Glen Layout, Near Central Mall',
    landmark: 'Opposite Cult.Fit Gym',
    area: 'Bellandur',
    city: 'Bengaluru',
    pinCode: '560103',
    lat: 12.9308,
    lng: 77.6229
  });

  const [notificationBanner, setNotificationBanner] = useState<{
    message: string;
    role: Role;
    timestamp: number;
  } | null>(null);

  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_shops`, JSON.stringify(shops));
  }, [shops]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_products`, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_orders`, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_riders`, JSON.stringify(riders));
  }, [riders]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_cart`, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY}_coupons`, JSON.stringify(coupons));
  }, [coupons]);

  // Subscribe to real-time cloud orders (Firestore) across devices
  useEffect(() => {
    const unsubscribe = listenToCloudOrders((cloudOrders) => {
      if (cloudOrders && cloudOrders.length > 0) {
        setOrders((prev) => {
          const orderMap = new Map<string, Order>();
          // Existing local orders
          prev.forEach((o) => orderMap.set(o.id, o));
          // Cloud orders override
          cloudOrders.forEach((o) => orderMap.set(o.id, o));
          const list = Array.from(orderMap.values());
          list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          return list;
        });
      }
    });

    return () => unsubscribe();
  }, []);

  // Subscribe to real-time cloud products (Firestore)
  useEffect(() => {
    // Seed initial products if cloud database is empty
    seedProductsToCloudIfEmpty(INITIAL_PRODUCTS);

    const unsubscribe = listenToCloudProducts((cloudProducts) => {
      if (cloudProducts && cloudProducts.length > 0) {
        setProducts((prev) => {
          const productMap = new Map<string, Product>();
          prev.forEach((p) => productMap.set(p.id, p));
          cloudProducts.forEach((p) => productMap.set(p.id, p));
          return Array.from(productMap.values());
        });
      }
    });

    return () => unsubscribe();
  }, []);

  // Subscribe to real-time cloud shops (Firestore)
  useEffect(() => {
    // Seed initial shops if cloud database is empty
    seedShopsToCloudIfEmpty(INITIAL_SHOPS);

    const unsubscribe = listenToCloudShops((cloudShops) => {
      if (cloudShops && cloudShops.length > 0) {
        setShops((prev) => {
          const shopMap = new Map<string, Shop>();
          prev.forEach((s) => shopMap.set(s.id, s));
          cloudShops.forEach((s) => shopMap.set(s.id, s));
          return Array.from(shopMap.values());
        });
      }
    });

    return () => unsubscribe();
  }, []);

  // Subscribe to real-time cloud coupons (Firestore)
  useEffect(() => {
    seedCouponsToCloudIfEmpty(INITIAL_COUPONS);

    const unsubscribe = listenToCloudCoupons((cloudCoupons) => {
      if (cloudCoupons && cloudCoupons.length > 0) {
        setCoupons((prev) => {
          const couponMap = new Map<string, Coupon>();
          prev.forEach((c) => couponMap.set(c.id, c));
          cloudCoupons.forEach((c) => couponMap.set(c.id, c));
          return Array.from(couponMap.values());
        });
      }
    });

    return () => unsubscribe();
  }, []);

  const clearNotification = () => setNotificationBanner(null);

  // --- Coupon Logic & Actions ---
  const getCartDiscount = (specificCoupon?: Coupon | null): number => {
    const target = specificCoupon !== undefined ? specificCoupon : appliedCoupon;
    if (!target || !target.isActive) return 0;
    const itemTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    if (itemTotal < target.minOrderAmount) return 0;

    let discount = 0;
    if (target.discountType === 'percentage') {
      const calculated = (itemTotal * target.discountValue) / 100;
      discount = target.maxDiscount ? Math.min(calculated, target.maxDiscount) : calculated;
    } else {
      discount = target.discountValue;
    }
    return Math.min(Math.round(discount), itemTotal);
  };

  const applyCoupon = (code: string) => {
    const trimmed = code.trim().toUpperCase();
    if (!trimmed) {
      return { success: false, message: 'Please enter a coupon code' };
    }
    const found = coupons.find((c) => c.code.toUpperCase() === trimmed);
    if (!found) {
      return { success: false, message: `Coupon "${trimmed}" not found or expired` };
    }
    if (!found.isActive) {
      return { success: false, message: `Coupon "${trimmed}" is currently inactive` };
    }
    const itemTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    if (itemTotal < found.minOrderAmount) {
      return {
        success: false,
        message: `Min order value for ${trimmed} is ₹${found.minOrderAmount}. Add ₹${found.minOrderAmount - itemTotal} more!`
      };
    }
    const discountAmount = getCartDiscount(found);
    setAppliedCoupon(found);
    soundEffects.playSuccessChime();
    return {
      success: true,
      message: `Coupon ${found.code} applied! You saved ₹${discountAmount}.`,
      discountAmount
    };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
  };

  const addCoupon = (couponData: Omit<Coupon, 'id'>) => {
    const id = `coup-${Date.now()}`;
    const newCoupon: Coupon = {
      ...couponData,
      id,
      code: couponData.code.trim().toUpperCase(),
      usageCount: 0,
      createdAt: new Date().toISOString()
    };
    setCoupons((prev) => [newCoupon, ...prev]);
    saveCouponToCloud(newCoupon);
  };

  const updateCoupon = (coupon: Coupon) => {
    setCoupons((prev) =>
      prev.map((c) => (c.id === coupon.id ? coupon : c))
    );
    saveCouponToCloud(coupon);
  };

  const deleteCoupon = (id: string) => {
    setCoupons((prev) => prev.filter((c) => c.id !== id));
    if (appliedCoupon?.id === id) setAppliedCoupon(null);
    deleteCouponFromCloud(id);
  };

  const toggleCouponStatus = (id: string) => {
    setCoupons((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          const updated = { ...c, isActive: !c.isActive };
          saveCouponToCloud(updated);
          if (!updated.isActive && appliedCoupon?.id === id) {
            setAppliedCoupon(null);
          }
          return updated;
        }
        return c;
      })
    );
  };

  // --- Cart Actions ---
  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  // --- Place Order ---
  const placeOrder = (
    payment: { method: PaymentDetails['method']; upiId?: string; transactionId?: string },
    tip: number = 10
  ): Order => {
    const currentShop = shops.find((s) => s.id === activeShopId) || shops[0];
    const itemTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const deliveryFee = itemTotal > 99 ? 0 : 25;
    const handlingFee = 2;
    const discount = getCartDiscount();
    const grandTotal = Math.max(0, itemTotal - discount) + deliveryFee + handlingFee + tip;

    // Random 4 digit OTP for anti-theft delivery verification
    const randomOtp = Math.floor(1000 + Math.random() * 9000).toString();
    const orderNumber = `QB-${Math.floor(10000 + Math.random() * 90000)}`;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber,
      shopId: currentShop.id,
      shopName: currentShop.name,
      shopPhone: currentShop.phone,
      shopAddress: currentShop.address,
      customerName: 'Sanket Patil',
      customerPhone: '+91 98451 99001',
      customerAddress: selectedAddress,
      items: cart.map((item) => ({
        productId: item.product.id,
        name: item.product.name,
        unit: item.product.unit,
        price: item.product.price,
        quantity: item.quantity,
        imageUrl: item.product.imageUrl,
        isPacked: false
      })),
      bill: {
        itemTotal,
        deliveryFee,
        handlingFee,
        tip,
        discount,
        grandTotal
      },
      couponCode: appliedCoupon?.code,
      payment: {
        method: payment.method,
        upiId: payment.upiId,
        // Only ever marked "paid" when a real, server-verified transactionId
        // was supplied (see CartDrawer's Razorpay verify step). COD stays pending.
        status: payment.method !== 'cod' && payment.transactionId ? 'paid' : 'pending',
        transactionId: payment.transactionId || '',
        paidAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      },
      status: 'placed',
      otp: randomOtp,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      etaMinutes: 10,
      timeline: [
        {
          status: 'placed',
          title: 'Order Placed & Paid',
          timestamp: 'Just now',
          description: `Payment of ₹${grandTotal} verified via ${payment.method.toUpperCase()} UPI`
        }
      ]
    };

    // Increment coupon usage count if used
    if (appliedCoupon) {
      const updatedCoupon = {
        ...appliedCoupon,
        usageCount: (appliedCoupon.usageCount || 0) + 1
      };
      updateCoupon(updatedCoupon);
      setAppliedCoupon(null);
    }

    setOrders((prev) => [newOrder, ...prev]);
    saveOrderToCloud(newOrder);
    clearCart();
    setActiveTrackingOrderId(newOrder.id);

    // Audio & alert triggers
    soundEffects.playOrderPlacedSound();
    setNotificationBanner({
      message: `🔔 New Order ${newOrder.orderNumber} (₹${grandTotal}) received for ${currentShop.name}!`,
      role: 'shopkeeper',
      timestamp: Date.now()
    });

    // Auto notify shopkeeper with chime
    setTimeout(() => {
      soundEffects.playNewOrderAlert();
    }, 600);

    return newOrder;
  };

  // --- Shopkeeper Actions ---
  const acceptOrder = (orderId: string) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id !== orderId) return ord;
        const updated: Order = {
          ...ord,
          status: 'packing',
          updatedAt: new Date().toISOString(),
          timeline: [
            ...ord.timeline,
            {
              status: 'packing',
              title: 'Store Accepted & Packing',
              timestamp: 'Just now',
              description: `${ord.shopName} started packing items into the delivery bag`
            }
          ]
        };
        saveOrderToCloud(updated);
        return updated;
      })
    );
  };

  const toggleItemPacked = (orderId: string, productId: string) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id !== orderId) return ord;
        const updatedItems = ord.items.map((item) =>
          item.productId === productId ? { ...item, isPacked: !item.isPacked } : item
        );
        return { ...ord, items: updatedItems };
      })
    );
  };

  const markOrderPacked = (orderId: string) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id !== orderId) return ord;
        // Also auto-mark all items packed
        const packedItems = ord.items.map((i) => ({ ...i, isPacked: true }));
        const updated: Order = {
          ...ord,
          status: 'packed',
          items: packedItems,
          updatedAt: new Date().toISOString(),
          timeline: [
            ...ord.timeline,
            {
              status: 'packed',
              title: 'Order Packed & Sealed',
              timestamp: 'Just now',
              description: 'Bag sealed with tamper-proof tag. Waiting for delivery partner pickup.'
            }
          ]
        };
        saveOrderToCloud(updated);
        return updated;
      })
    );

    // Play loud alert for nearby delivery partner
    soundEffects.playRiderAlert();
    setNotificationBanner({
      message: `🛵 Pickup Ready! Order from ${orders.find((o) => o.id === orderId)?.shopName || 'Store'} is packed!`,
      role: 'delivery',
      timestamp: Date.now()
    });
  };

  const addProduct = (newProd: Omit<Product, 'id'>) => {
    const id = `p-${Date.now()}`;
    const product: Product = { ...newProd, id };
    setProducts((prev) => [product, ...prev]);
    saveProductToCloud(product);
  };

  const updateProduct = (productId: string, updates: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((prod) => {
        if (prod.id === productId) {
          const updated = { ...prod, ...updates };
          saveProductToCloud(updated);
          return updated;
        }
        return prod;
      })
    );
  };

  const deleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    deleteProductFromCloud(productId);
  };

  const updateShopSettings = (shopId: string, updates: Partial<Shop>) => {
    setShops((prev) =>
      prev.map((s) => {
        if (s.id === shopId) {
          const updated = { ...s, ...updates };
          saveShopToCloud(updated);
          return updated;
        }
        return s;
      })
    );
  };

  const onboardNewShop = (newShopData: Omit<Shop, 'id' | 'rating' | 'totalOrders'>) => {
    const id = `shop-${Date.now()}`;
    const newShop: Shop = {
      ...newShopData,
      id,
      rating: 5.0,
      totalOrders: 0
    };
    setShops((prev) => [...prev, newShop]);
    setActiveShopId(newShop.id);
    saveShopToCloud(newShop);
  };

  // --- Rider Actions ---
  const acceptDeliveryTask = (orderId: string, riderId: string) => {
    const rider = riders.find((r) => r.id === riderId) || riders[0];
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id !== orderId) return ord;
        const updated: Order = {
          ...ord,
          status: 'assigned',
          deliveryPartner: rider,
          updatedAt: new Date().toISOString(),
          timeline: [
            ...ord.timeline,
            {
              status: 'assigned',
              title: `Rider ${rider.name} Assigned`,
              timestamp: 'Just now',
              description: `${rider.name} (${rider.vehicleNumber}) is reaching ${ord.shopName} to pick up`
            }
          ]
        };
        saveOrderToCloud(updated);
        return updated;
      })
    );
  };

  const confirmPickup = (orderId: string) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id !== orderId) return ord;
        const updated: Order = {
          ...ord,
          status: 'out_for_delivery',
          etaMinutes: 6,
          updatedAt: new Date().toISOString(),
          timeline: [
            ...ord.timeline,
            {
              status: 'out_for_delivery',
              title: 'Out for Delivery 🚀',
              timestamp: 'Just now',
              description: 'Partner has collected the order and is on the way to your door'
            }
          ]
        };
        saveOrderToCloud(updated);
        return updated;
      })
    );
  };

  const verifyAndDeliver = (orderId: string, enteredOtp: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return { success: false, message: 'Order not found' };

    if (enteredOtp.trim() !== order.otp.trim()) {
      return { success: false, message: `Invalid Delivery PIN! Ask customer for their 4-digit OTP.` };
    }

    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id !== orderId) return ord;
        const updated: Order = {
          ...ord,
          status: 'delivered',
          etaMinutes: 0,
          updatedAt: new Date().toISOString(),
          timeline: [
            ...ord.timeline,
            {
              status: 'delivered',
              title: 'Delivered at Doorstep 🎉',
              timestamp: 'Just now',
              description: `Verified with 4-digit OTP. Delivered by ${ord.deliveryPartner?.name || 'Partner'}. Enjoy your groceries!`
            }
          ]
        };
        saveOrderToCloud(updated);
        return updated;
      })
    );

    // Increase rider earnings
    setRiders((prev) =>
      prev.map((r) => {
        if (r.id === (order.deliveryPartner?.id || activeRiderId)) {
          return {
            ...r,
            todayEarnings: r.todayEarnings + 45 + (order.bill.tip || 0),
            completedDeliveries: r.completedDeliveries + 1
          };
        }
        return r;
      })
    );

    soundEffects.playSuccessChime();
    setNotificationBanner({
      message: `🎉 Order ${order.orderNumber} successfully delivered to ${order.customerName}! OTP verified.`,
      role: 'customer',
      timestamp: Date.now()
    });

    return { success: true, message: 'Delivery Completed! Earning ₹45 + tip credited.' };
  };

  const toggleRiderDuty = (riderId: string) => {
    setRiders((prev) =>
      prev.map((r) => (r.id === riderId ? { ...r, isOnline: !r.isOnline } : r))
    );
  };

  // Push a live GPS position for the rider currently delivering `orderId`.
  // Updates local state immediately (so the rider's own screen feels instant)
  // and syncs to Firestore so the customer's live map updates in real time too.
  const updateRiderLocation = (orderId: string, lat: number, lng: number) => {
    const updatedAt = new Date().toISOString();
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, riderLocation: { lat, lng, updatedAt } } : o))
    );
    updateOrderLocation(orderId, lat, lng);
  };

  // --- Admin Actions ---
  const updateShopCommission = (shopId: string, commission: number) => {
    setShops((prev) =>
      prev.map((s) => {
        if (s.id === shopId) {
          const updated = { ...s, commissionPercent: commission };
          saveShopToCloud(updated);
          return updated;
        }
        return s;
      })
    );
  };

  const toggleShopStatus = (shopId: string) => {
    setShops((prev) =>
      prev.map((s) => {
        if (s.id === shopId) {
          const updated = { ...s, isOpen: !s.isOpen };
          saveShopToCloud(updated);
          return updated;
        }
        return s;
      })
    );
  };

  const cancelOrder = (orderId: string, reason: string) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id !== orderId) return ord;
        const updated: Order = {
          ...ord,
          status: 'cancelled',
          timeline: [
            ...ord.timeline,
            {
              status: 'cancelled',
              title: 'Order Cancelled by Admin',
              timestamp: 'Just now',
              description: reason
            }
          ]
        };
        saveOrderToCloud(updated);
        return updated;
      })
    );
  };

  const resetAllData = () => {
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_shops`);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_products`);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_orders`);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_riders`);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_cart`);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY}_coupons`);
    setShops(INITIAL_SHOPS);
    setProducts(INITIAL_PRODUCTS);
    setOrders(INITIAL_ORDERS);
    setRiders(INITIAL_RIDERS);
    setCart([]);
    setCoupons(INITIAL_COUPONS);
    setAppliedCoupon(null);
    setActiveTrackingOrderId(INITIAL_ORDERS[0]?.id || null);
  };

  // --- Live Interactive End-to-End Simulation ---
  const triggerLiveSimulation = () => {
    if (isSimulating) return;
    setIsSimulating(true);

    // 1. Customer places order
    const simOrder = placeOrder({ method: 'gpay', upiId: 'live_demo@okhdfcbank' }, 20);

    // 2. Switch to Shopkeeper after 3s & accept
    setTimeout(() => {
      setRole('shopkeeper');
      acceptOrder(simOrder.id);

      // 3. Mark packed after another 3s
      setTimeout(() => {
        markOrderPacked(simOrder.id);

        // 4. Switch to Rider after 3s & accept + pickup
        setTimeout(() => {
          setRole('delivery');
          acceptDeliveryTask(simOrder.id, activeRiderId);

          setTimeout(() => {
            confirmPickup(simOrder.id);

            // 5. Switch to Customer tracking map after 3s
            setTimeout(() => {
              setRole('customer');
              setActiveTrackingOrderId(simOrder.id);

              // 6. Complete delivery after 4s
              setTimeout(() => {
                verifyAndDeliver(simOrder.id, simOrder.otp);
                setIsSimulating(false);
              }, 4000);
            }, 3000);
          }, 3000);
        }, 3000);
      }, 3000);
    }, 3000);
  };

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        isMobileSimulator,
        setIsMobileSimulator,
        isMultiScreenMode,
        setIsMultiScreenMode,
        activeShopId,
        setActiveShopId,
        activeRiderId,
        setActiveRiderId,
        shops,
        products,
        orders,
        riders,
        cart,
        coupons,
        appliedCoupon,
        applyCoupon,
        removeCoupon,
        addCoupon,
        updateCoupon,
        deleteCoupon,
        toggleCouponStatus,
        getCartDiscount,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        selectedAddress,
        setSelectedAddress,
        placeOrder,
        activeTrackingOrderId,
        setActiveTrackingOrderId,
        acceptOrder,
        toggleItemPacked,
        markOrderPacked,
        addProduct,
        updateProduct,
        deleteProduct,
        updateShopSettings,
        onboardNewShop,
        acceptDeliveryTask,
        confirmPickup,
        verifyAndDeliver,
        toggleRiderDuty,
        updateRiderLocation,
        updateShopCommission,
        toggleShopStatus,
        cancelOrder,
        resetAllData,
        notificationBanner,
        clearNotification,
        triggerLiveSimulation,
        isSimulating
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
