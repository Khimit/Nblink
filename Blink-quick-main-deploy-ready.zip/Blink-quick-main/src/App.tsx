import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { CustomerApp } from './components/Customer/CustomerApp';
import { ShopkeeperPortal } from './components/Shopkeeper/ShopkeeperPortal';
import { DeliveryApp } from './components/Delivery/DeliveryApp';
import { AdminPortal } from './components/Admin/AdminPortal';
import { MultiScreenView } from './components/MultiScreenView';
import { PlayStoreModal } from './components/PlayStoreModal';
import {
  Wifi,
  BatteryMedium,
  Signal,
  ShoppingBag,
  Store,
  Bike,
  ShieldCheck,
  Play
} from 'lucide-react';

const MainAppContent: React.FC = () => {
  const {
    role,
    setRole,
    isMobileSimulator,
    isMultiScreenMode,
    triggerLiveSimulation,
    isSimulating
  } = useApp();
  const [isPlayStoreOpen, setIsPlayStoreOpen] = useState(false);

  const renderActiveRole = () => {
    switch (role) {
      case 'customer':
        return <CustomerApp />;
      case 'shopkeeper':
        return <ShopkeeperPortal />;
      case 'delivery':
        return <DeliveryApp />;
      case 'admin':
        return <AdminPortal />;
      default:
        return <CustomerApp />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Top Navbar */}
      <Header onOpenPlayStoreModal={() => setIsPlayStoreOpen(true)} />

      {/* Main App Canvas */}
      <div className="flex-1 w-full">
        {isMultiScreenMode ? (
          <MultiScreenView />
        ) : isMobileSimulator ? (
          /* Realistic Android Phone Device Simulator Frame */
          <div className="py-6 px-4 flex justify-center items-start min-h-[calc(100vh-4rem)]">
            <div className="relative w-full max-w-[400px] bg-white rounded-[44px] shadow-2xl border-[10px] border-slate-900 overflow-hidden flex flex-col min-h-[800px] ring-1 ring-slate-900/20">
              {/* Android Top Notch & Status Bar */}
              <div className="bg-slate-950 text-white px-6 py-2.5 flex items-center justify-between text-[11px] font-semibold select-none shrink-0 z-50">
                <span>9:41</span>
                {/* Camera punch hole */}
                <div className="w-4 h-4 bg-black rounded-full border border-slate-800" />
                <div className="flex items-center gap-1.5 text-slate-300">
                  <Signal className="w-3.5 h-3.5" />
                  <Wifi className="w-3.5 h-3.5" />
                  <BatteryMedium className="w-4 h-4" />
                </div>
              </div>

              {/* In-Phone Scrollable Screen Viewport */}
              <div className="flex-1 overflow-y-auto bg-slate-50 relative">
                {renderActiveRole()}
              </div>

              {/* In-Phone Bottom Navigation Bar */}
              <div className="bg-white border-t border-slate-200 px-3 py-2 flex items-center justify-around shrink-0 z-40">
                <button
                  onClick={() => setRole('customer')}
                  className={`flex flex-col items-center gap-0.5 text-[10px] font-bold ${
                    role === 'customer' ? 'text-emerald-700' : 'text-slate-400'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Shop</span>
                </button>
                <button
                  onClick={() => setRole('shopkeeper')}
                  className={`flex flex-col items-center gap-0.5 text-[10px] font-bold ${
                    role === 'shopkeeper' ? 'text-emerald-700' : 'text-slate-400'
                  }`}
                >
                  <Store className="w-4 h-4" />
                  <span>Kirana</span>
                </button>
                <button
                  onClick={() => setRole('delivery')}
                  className={`flex flex-col items-center gap-0.5 text-[10px] font-bold ${
                    role === 'delivery' ? 'text-emerald-700' : 'text-slate-400'
                  }`}
                >
                  <Bike className="w-4 h-4" />
                  <span>Rider</span>
                </button>
                <button
                  onClick={() => setRole('admin')}
                  className={`flex flex-col items-center gap-0.5 text-[10px] font-bold ${
                    role === 'admin' ? 'text-emerald-700' : 'text-slate-400'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Admin</span>
                </button>
              </div>

              {/* Android Bottom Home Gesture Indicator */}
              <div className="bg-white pb-2 flex justify-center shrink-0">
                <div className="w-32 h-1 bg-slate-400 rounded-full" />
              </div>
            </div>
          </div>
        ) : (
          /* Full Responsive Viewport */
          <div className="w-full">{renderActiveRole()}</div>
        )}
      </div>

      {/* Play Store Modal */}
      <PlayStoreModal
        isOpen={isPlayStoreOpen}
        onClose={() => setIsPlayStoreOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
