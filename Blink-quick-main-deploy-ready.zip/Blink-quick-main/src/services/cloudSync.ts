import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  limit,
  getDocs
} from 'firebase/firestore';
import { db } from '../firebase';
import { Order, Shop, Product, DeliveryPartner, Coupon } from '../types';

/**
 * Push a live GPS position update for the rider assigned to an order.
 * Written as a partial merge so it doesn't clobber the rest of the order,
 * and picked up in real time by every device subscribed via listenToCloudOrders.
 */
export async function updateOrderLocation(
  orderId: string,
  lat: number,
  lng: number
): Promise<void> {
  try {
    const orderDocRef = doc(db, 'orders', orderId);
    await setDoc(
      orderDocRef,
      {
        riderLocation: {
          lat,
          lng,
          updatedAt: new Date().toISOString()
        }
      },
      { merge: true }
    );
  } catch (error) {
    console.warn('Firestore rider location update notice:', error);
  }
}

/**
 * Save or update an order in Firestore
 */
export async function saveOrderToCloud(order: Order): Promise<void> {
  try {
    const orderDocRef = doc(db, 'orders', order.id);
    await setDoc(orderDocRef, order, { merge: true });
    console.log(`Cloud sync: Order ${order.orderNumber} saved to Firestore`);
  } catch (error) {
    console.warn('Firestore order write notice:', error);
  }
}

/**
 * Listen to real-time order updates across all connected devices (Customer, Kirana, Delivery, Admin)
 */
export function listenToCloudOrders(
  onUpdate: (cloudOrders: Order[]) => void
): () => void {
  try {
    const ordersCol = collection(db, 'orders');
    const q = query(ordersCol, limit(100));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        if (!snapshot.empty) {
          const list: Order[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as Order;
            list.push(data);
          });
          list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          onUpdate(list);
        }
      },
      (error) => {
        console.warn('Firestore orders snapshot notice:', error);
      }
    );

    return unsubscribe;
  } catch (error) {
    console.warn('Firestore orders listener initialization notice:', error);
    return () => {};
  }
}

/**
 * Save or update a product in Firestore
 */
export async function saveProductToCloud(product: Product): Promise<void> {
  try {
    const productRef = doc(db, 'products', product.id);
    await setDoc(productRef, product, { merge: true });
    console.log(`Cloud sync: Product ${product.name} saved to Firestore`);
  } catch (error) {
    console.warn('Firestore product write notice:', error);
  }
}

/**
 * Delete a product from Firestore
 */
export async function deleteProductFromCloud(productId: string): Promise<void> {
  try {
    const productRef = doc(db, 'products', productId);
    await deleteDoc(productRef);
    console.log(`Cloud sync: Product ${productId} deleted from Firestore`);
  } catch (error) {
    console.warn('Firestore product delete notice:', error);
  }
}

/**
 * Listen to real-time products catalog from Firestore
 */
export function listenToCloudProducts(
  onUpdate: (products: Product[]) => void
): () => void {
  try {
    const productsCol = collection(db, 'products');
    const unsubscribe = onSnapshot(
      productsCol,
      (snapshot) => {
        if (!snapshot.empty) {
          const list: Product[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as Product);
          });
          onUpdate(list);
        }
      },
      (error) => {
        console.warn('Firestore products listener notice:', error);
      }
    );
    return unsubscribe;
  } catch (error) {
    console.warn('Firestore products listener error:', error);
    return () => {};
  }
}

/**
 * Seed initial products to Firestore if collection is empty
 */
export async function seedProductsToCloudIfEmpty(initialProducts: Product[]): Promise<void> {
  try {
    const productsCol = collection(db, 'products');
    const existing = await getDocs(query(productsCol, limit(1)));
    if (existing.empty) {
      console.log('Seeding initial grocery catalog to Firestore...');
      for (const prod of initialProducts) {
        await setDoc(doc(db, 'products', prod.id), prod);
      }
      console.log(`Seeded ${initialProducts.length} products to Firestore!`);
    }
  } catch (error) {
    console.warn('Firestore product seed notice:', error);
  }
}

/**
 * Save or update a Shop in Firestore
 */
export async function saveShopToCloud(shop: Shop): Promise<void> {
  try {
    const shopRef = doc(db, 'shops', shop.id);
    await setDoc(shopRef, shop, { merge: true });
    console.log(`Cloud sync: Shop ${shop.name} saved to Firestore`);
  } catch (error) {
    console.warn('Firestore shop write notice:', error);
  }
}

/**
 * Listen to registered partner Kirana shops from Firestore
 */
export function listenToCloudShops(
  onUpdate: (shops: Shop[]) => void
): () => void {
  try {
    const shopsCol = collection(db, 'shops');
    const unsubscribe = onSnapshot(
      shopsCol,
      (snapshot) => {
        if (!snapshot.empty) {
          const list: Shop[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as Shop);
          });
          onUpdate(list);
        }
      },
      (error) => {
        console.warn('Firestore shops listener notice:', error);
      }
    );
    return unsubscribe;
  } catch (error) {
    console.warn('Firestore shops listener error:', error);
    return () => {};
  }
}

/**
 * Seed initial shops to Firestore if collection is empty
 */
export async function seedShopsToCloudIfEmpty(initialShops: Shop[]): Promise<void> {
  try {
    const shopsCol = collection(db, 'shops');
    const existing = await getDocs(query(shopsCol, limit(1)));
    if (existing.empty) {
      console.log('Seeding initial partner shops to Firestore...');
      for (const shop of initialShops) {
        await setDoc(doc(db, 'shops', shop.id), shop);
      }
      console.log(`Seeded ${initialShops.length} shops to Firestore!`);
    }
  } catch (error) {
    console.warn('Firestore shops seed notice:', error);
  }
}

/**
 * Save or update a coupon in Firestore
 */
export async function saveCouponToCloud(coupon: Coupon): Promise<void> {
  try {
    const couponRef = doc(db, 'coupons', coupon.id);
    await setDoc(couponRef, coupon, { merge: true });
    console.log(`Cloud sync: Coupon ${coupon.code} saved to Firestore`);
  } catch (error) {
    console.warn('Firestore coupon write notice:', error);
  }
}

/**
 * Delete a coupon from Firestore
 */
export async function deleteCouponFromCloud(couponId: string): Promise<void> {
  try {
    const couponRef = doc(db, 'coupons', couponId);
    await deleteDoc(couponRef);
    console.log(`Cloud sync: Coupon ${couponId} deleted from Firestore`);
  } catch (error) {
    console.warn('Firestore coupon delete notice:', error);
  }
}

/**
 * Listen to real-time coupons from Firestore
 */
export function listenToCloudCoupons(
  onUpdate: (coupons: Coupon[]) => void
): () => void {
  try {
    const couponsCol = collection(db, 'coupons');
    const unsubscribe = onSnapshot(
      couponsCol,
      (snapshot) => {
        if (!snapshot.empty) {
          const list: Coupon[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as Coupon);
          });
          onUpdate(list);
        }
      },
      (error) => {
        console.warn('Firestore coupons listener notice:', error);
      }
    );
    return unsubscribe;
  } catch (error) {
    console.warn('Firestore coupons listener error:', error);
    return () => {};
  }
}

/**
 * Seed default promotional coupons to Firestore if empty
 */
export async function seedCouponsToCloudIfEmpty(initialCoupons: Coupon[]): Promise<void> {
  try {
    const couponsCol = collection(db, 'coupons');
    const existing = await getDocs(query(couponsCol, limit(1)));
    if (existing.empty) {
      console.log('Seeding initial promotional coupons to Firestore...');
      for (const c of initialCoupons) {
        await setDoc(doc(db, 'coupons', c.id), c);
      }
      console.log(`Seeded ${initialCoupons.length} coupons to Firestore!`);
    }
  } catch (error) {
    console.warn('Firestore coupons seed notice:', error);
  }
}


