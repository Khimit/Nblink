import React, { useState } from 'react';
import {
  ShieldCheck,
  TrendingUp,
  Store,
  Bike,
  Package,
  DollarSign,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Search,
  Download,
  Smartphone,
  Copy,
  Check,
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { OrderStatus } from '../../types';

export const AdminPortal: React.FC = () => {
  const {
    shops,
    products,
    orders,
    riders,
    updateShopCommission,
    toggleShopStatus,
    cancelOrder,
    resetAllData
  } = useApp();

  const [activeTab, setActiveTab] = useState<'dispatch' | 'shops' | 'riders' | 'playstore'>('dispatch');
  const [copiedText, setCopiedText] = useState<string>('');

  // Overall platform KPIs
  const totalGMV = orders.reduce((sum, o) => (o.status !== 'cancelled' ? sum + o.bill.grandTotal : sum), 0);
  const totalOrders = orders.length;
  const activeOrdersCount = orders.filter((o) => o.status !== 'delivered' && o.status !== 'cancelled').length;
  const totalCommissionRevenue = orders
    .filter((o) => o.status === 'delivered')
    .reduce((sum, o) => {
      const shop = shops.find((s) => s.id === o.shopId);
      const rate = shop?.commissionPercent || 5;
      return sum + Math.round((o.bill.itemTotal * rate) / 100);
    }, 0);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(''), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Admin Title & Master Reset Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 text-white p-6 rounded-3xl border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-600 flex items-center justify-center font-bold text-white shadow-lg shadow-emerald-600/30">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-black tracking-tight">
                QuickBlink Super Admin HQ
              </h1>
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                Hyperlocal Control
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Real-time monitoring across customer orders, partner kirana stores, and delivery riders.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              if (confirm('Reset demo state to initial fresh data?')) {
                resetAllData();
              }
            }}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Demo State</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Platform GMV</span>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-1">₹{totalGMV}</div>
          <span className="text-[10px] text-emerald-600 font-bold">100% UPI & Cash</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Live Orders In-Flight</span>
          <div className="text-xl sm:text-2xl font-black text-amber-600 mt-1">{activeOrdersCount}</div>
          <span className="text-[10px] text-slate-400">Total: {totalOrders} orders</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Partner Kiranas</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-700 mt-1">{shops.length}</div>
          <span className="text-[10px] text-slate-400">
            {shops.filter((s) => s.isOpen).length} currently open
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Active Rider Fleet</span>
          <div className="text-xl sm:text-2xl font-black text-blue-600 mt-1">{riders.length}</div>
          <span className="text-[10px] text-slate-400">
            {riders.filter((r) => r.isOnline).length} on duty
          </span>
        </div>

        <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 shadow-xs col-span-2 lg:col-span-1">
          <span className="text-[11px] font-bold text-emerald-800 uppercase">Platform Commission</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-950 mt-1">₹{totalCommissionRevenue}</div>
          <span className="text-[10px] text-emerald-700 font-bold">5% Merchant share</span>
        </div>
      </div>

      {/* Admin Tab Switcher */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'dispatch', label: 'Live Dispatch Monitor', icon: Package, count: activeOrdersCount },
          { id: 'shops', label: 'Partner Kirana Stores', icon: Store, count: shops.length },
          { id: 'riders', label: 'Delivery Fleet', icon: Bike, count: riders.length },
          { id: 'playstore', label: 'Play Store TWA Export Kit', icon: Smartphone }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                    isActive ? 'bg-emerald-500 text-slate-950' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: LIVE DISPATCH MONITOR */}
      {activeTab === 'dispatch' && (
        <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
              City-Wide Live Order Dispatch
            </h3>
            <span className="text-xs text-slate-500 font-medium">
              Auto-syncs with customer & shopkeeper actions
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3.5">Order #</th>
                  <th className="p-3.5">Customer & Area</th>
                  <th className="p-3.5">Partner Kirana</th>
                  <th className="p-3.5">Items & Value</th>
                  <th className="p-3.5">Assigned Rider</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Delivery OTP</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {orders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-3.5 font-mono font-black text-slate-900">
                      {ord.orderNumber}
                    </td>
                    <td className="p-3.5">
                      <span className="font-bold text-slate-900 block">{ord.customerName}</span>
                      <span className="text-[10px] text-slate-400">{ord.customerAddress.area}</span>
                    </td>
                    <td className="p-3.5">
                      <span className="font-bold text-slate-800 block">{ord.shopName}</span>
                      <span className="text-[10px] text-slate-400">Shop ID: {ord.shopId}</span>
                    </td>
                    <td className="p-3.5">
                      <span className="font-black text-slate-900">₹{ord.bill.grandTotal}</span>
                      <span className="text-[10px] text-slate-400 block font-medium">
                        ({ord.items.length} items • {ord.payment.method.toUpperCase()})
                      </span>
                    </td>
                    <td className="p-3.5">
                      {ord.deliveryPartner ? (
                        <div>
                          <span className="font-bold text-slate-900 block">
                            {ord.deliveryPartner.name}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {ord.deliveryPartner.vehicleNumber}
                          </span>
                        </div>
                      ) : (
                        <span className="text-[11px] text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded-md">
                          Awaiting Rider
                        </span>
                      )}
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                          ord.status === 'placed'
                            ? 'bg-amber-100 text-amber-900 animate-pulse'
                            : ord.status === 'packing'
                            ? 'bg-blue-100 text-blue-900'
                            : ord.status === 'packed'
                            ? 'bg-purple-100 text-purple-900'
                            : ord.status === 'out_for_delivery'
                            ? 'bg-indigo-100 text-indigo-900'
                            : ord.status === 'delivered'
                            ? 'bg-emerald-100 text-emerald-900'
                            : 'bg-rose-100 text-rose-900'
                        }`}
                      >
                        {ord.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span className="font-mono font-black text-xs text-slate-800 bg-slate-100 px-2 py-1 rounded-md">
                        {ord.otp}
                      </span>
                    </td>
                    <td className="p-3.5 text-right">
                      {ord.status !== 'delivered' && ord.status !== 'cancelled' && (
                        <button
                          onClick={() => cancelOrder(ord.id, 'Admin intervention')}
                          className="text-[10px] font-bold text-rose-600 hover:underline"
                        >
                          Cancel
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: PARTNER KIRANAS */}
      {activeTab === 'shops' && (
        <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
              Onboarded Partner Kirana Stores ({shops.length})
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3.5">Shop Name</th>
                  <th className="p-3.5">Owner & Contact</th>
                  <th className="p-3.5">UPI Settlement Handle</th>
                  <th className="p-3.5">Commission %</th>
                  <th className="p-3.5">Total Orders</th>
                  <th className="p-3.5">Store Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {shops.map((shop) => (
                  <tr key={shop.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-3.5">
                      <div className="flex items-center gap-3">
                        <img
                          src={shop.bannerUrl}
                          alt={shop.name}
                          className="w-10 h-10 object-cover rounded-xl shrink-0"
                        />
                        <div>
                          <span className="font-bold text-slate-900 block">{shop.name}</span>
                          <span className="text-[10px] text-slate-400">{shop.area}</span>
                        </div>
                      </div>
                    </td>
                    <td className="p-3.5">
                      <span className="font-bold text-slate-800 block">{shop.ownerName}</span>
                      <span className="text-[10px] text-slate-400">{shop.phone}</span>
                    </td>
                    <td className="p-3.5 font-mono text-emerald-800 font-bold">
                      {shop.upiId}
                    </td>
                    <td className="p-3.5">
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          value={shop.commissionPercent}
                          onChange={(e) => updateShopCommission(shop.id, Number(e.target.value))}
                          className="w-14 px-2 py-1 border border-slate-200 rounded-lg text-xs font-bold text-slate-900"
                        />
                        <span className="font-bold">%</span>
                      </div>
                    </td>
                    <td className="p-3.5 font-bold text-slate-800">
                      {shop.totalOrders}
                    </td>
                    <td className="p-3.5">
                      <button
                        onClick={() => toggleShopStatus(shop.id)}
                        className={`px-2.5 py-1 rounded-full font-bold text-[10px] uppercase transition-colors ${
                          shop.isOpen
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {shop.isOpen ? 'Verified & Open' : 'Store Closed'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: DELIVERY FLEET */}
      {activeTab === 'riders' && (
        <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
              Rider Fleet Registry ({riders.length})
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3.5">Rider</th>
                  <th className="p-3.5">Vehicle & Reg No.</th>
                  <th className="p-3.5">Phone</th>
                  <th className="p-3.5">Rating</th>
                  <th className="p-3.5">Duty Status</th>
                  <th className="p-3.5">Today's Payout</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {riders.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-3.5">
                      <div className="flex items-center gap-3">
                        <img
                          src={r.photo}
                          alt={r.name}
                          className="w-10 h-10 object-cover rounded-xl border border-slate-200 shrink-0"
                        />
                        <span className="font-bold text-slate-900">{r.name}</span>
                      </div>
                    </td>
                    <td className="p-3.5">
                      <span className="font-bold text-slate-800 block">{r.vehicle}</span>
                      <span className="text-[10px] text-slate-400 font-mono font-bold">
                        {r.vehicleNumber}
                      </span>
                    </td>
                    <td className="p-3.5 font-medium">{r.phone}</td>
                    <td className="p-3.5">
                      <span className="bg-emerald-50 text-emerald-800 font-black px-2 py-0.5 rounded-md">
                        ★ {r.rating}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                          r.isOnline
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {r.isOnline ? 'Online (Ready)' : 'Offline'}
                      </span>
                    </td>
                    <td className="p-3.5 font-black text-emerald-800">
                      ₹{r.todayEarnings} ({r.completedDeliveries} orders)
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: PLAY STORE TWA / APK EXPORT KIT */}
      {activeTab === 'playstore' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
          <div>
            <div className="flex items-center gap-2">
              <Smartphone className="w-6 h-6 text-emerald-600" />
              <h3 className="font-black text-slate-900 text-lg">
                Google Play Store TWA (Trusted Web Activity) / APK Deployment Kit
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1 max-w-2xl">
              This QuickBlink web application complies fully with Google Play Store PWA and Trusted Web Activity standards. Follow the instructions below to compile an Android App Bundle (.aab) or APK and publish directly to Google Play Console!
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Step 1: Package Identity */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
              <span className="font-black text-slate-900 uppercase tracking-wider block">
                1. Android Package Configuration
              </span>
              <div className="space-y-1 text-slate-600">
                <div>Package Name: <strong className="font-mono text-slate-900">com.quickblink.delivery</strong></div>
                <div>App Title: <strong className="text-slate-900">QuickBlink: 10 Min Grocery Delivery</strong></div>
                <div>Start URL: <strong className="font-mono text-slate-900">https://your-domain.run.app/</strong></div>
                <div>Theme Color: <strong className="font-mono text-emerald-700">#0c831f</strong></div>
                <div>Display Mode: <strong className="font-mono text-slate-900">standalone</strong></div>
              </div>
            </div>

            {/* Step 2: Bubblewrap / PWABuilder CLI */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-black text-slate-900 uppercase tracking-wider block">
                  2. 1-Command APK Build (Bubblewrap CLI)
                </span>
                <button
                  onClick={() =>
                    copyToClipboard(
                      'npm i -g @bubblewrap/cli\nbubblewrap init --manifest=https://your-domain.run.app/manifest.json\nbubblewrap build',
                      'bubblewrap'
                    )
                  }
                  className="text-emerald-700 font-bold hover:underline flex items-center gap-1"
                >
                  {copiedText === 'bubblewrap' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  <span>Copy Commands</span>
                </button>
              </div>
              <pre className="p-2.5 bg-slate-900 text-emerald-400 rounded-xl font-mono text-[11px] overflow-x-auto">
{`# 1. Install Google Bubblewrap CLI
npm i -g @bubblewrap/cli

# 2. Initialize TWA from Web Manifest
bubblewrap init --manifest=/manifest.json

# 3. Compile signed release Android APK / AAB
bubblewrap build`}
              </pre>
            </div>
          </div>

          {/* Digital Asset Links Config */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-black text-slate-900 uppercase tracking-wider block">
                3. Digital Asset Links (for Fullscreen Native Experience without URL bar)
              </span>
              <button
                onClick={() =>
                  copyToClipboard(
                    JSON.stringify(
                      [
                        {
                          relation: ['delegate_permission/common.handle_all_urls'],
                          target: {
                            namespace: 'android_app',
                            package_name: 'com.quickblink.delivery',
                            sha256_cert_fingerprints: [
                              '14:6D:E9:7D:0F:52:CC:72:08:92:EB:6E:9B:0F:7B:64:9C:2C:94:0A:7A:B3:68:55:76:7D:1E:E7:E8:2F:DF:39'
                            ]
                          }
                        }
                      ],
                      null,
                      2
                    ),
                    'assetlinks'
                  )
                }
                className="text-emerald-700 font-bold hover:underline flex items-center gap-1"
              >
                {copiedText === 'assetlinks' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                <span>Copy assetlinks.json</span>
              </button>
            </div>
            <p className="text-slate-500 text-[11px]">
              Host this JSON at <code className="bg-white px-1.5 py-0.5 rounded border border-slate-300">/.well-known/assetlinks.json</code> on your server to verify ownership with Google Play.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
