import React, { useState } from 'react';
import {
  X,
  ShoppingBag,
  Store,
  Bike,
  ShieldCheck,
  ExternalLink,
  Copy,
  Check,
  Smartphone,
  Layers,
  ArrowRight,
  Sparkles,
  Cloud
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Role } from '../types';

interface AppPortalsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppPortalsModal: React.FC<AppPortalsModalProps> = ({ isOpen, onClose }) => {
  const { role, setRole, isMultiScreenMode, setIsMultiScreenMode } = useApp();
  const [copiedRole, setCopiedRole] = useState<string | null>(null);

  if (!isOpen) return null;

  const getBaseUrl = () => {
    if (typeof window !== 'undefined') {
      return `${window.location.origin}${window.location.pathname}`;
    }
    return 'https://ais-pre-ftawgxajh4px44b2vmo74h-940101671865.asia-east1.run.app';
  };

  const portals: {
    id: Role;
    title: string;
    badge: string;
    badgeColor: string;
    icon: React.ElementType;
    iconBg: string;
    targetUser: string;
    description: string;
    keyFeatures: string[];
    accentColor: string;
  }[] = [
    {
      id: 'customer',
      title: 'Customer Grocery App',
      badge: 'B2C App Store',
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      icon: ShoppingBag,
      iconBg: 'bg-emerald-600 text-white',
      targetUser: 'Everyday Consumers (Shoppers)',
      description: 'Ultra-fast 10-minute grocery shopping with search, cart, UPI checkout & live rider map tracking.',
      keyFeatures: [
        'Live 10-min ETA countdown',
        'Instant UPI QR / One-click payment',
        'Real-time GPS delivery tracking',
        '4-Digit Secure Delivery OTP'
      ],
      accentColor: 'hover:border-emerald-500'
    },
    {
      id: 'shopkeeper',
      title: 'Partner Kirana Store OS',
      badge: 'Merchant App',
      badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
      icon: Store,
      iconBg: 'bg-blue-600 text-white',
      targetUser: 'Kirana Store Owners & Packers',
      description: 'Store terminal with loud incoming order bell, digital packing checklist, and live inventory toggle.',
      keyFeatures: [
        'Loud Audio Chime on new orders',
        'Item-by-item packing checklist',
        'Stock availability switch',
        'Daily store payouts & settlements'
      ],
      accentColor: 'hover:border-blue-500'
    },
    {
      id: 'delivery',
      title: 'Rider & Delivery Partner App',
      badge: 'Fleet App',
      badgeColor: 'bg-amber-100 text-amber-900 border-amber-200',
      icon: Bike,
      iconBg: 'bg-amber-500 text-slate-950',
      targetUser: 'Delivery Fleet / Gig Workers',
      description: 'High-contrast rider cockpit with Duty shift toggle, GPS route map, and OTP PIN anti-theft verification.',
      keyFeatures: [
        'Online / Offline Duty toggle',
        'Pickup navigation & distance radar',
        'Customer OTP entry to complete delivery',
        'Shift earnings tracker (₹45/drop + tips)'
      ],
      accentColor: 'hover:border-amber-500'
    },
    {
      id: 'admin',
      title: 'Operations HQ Control Tower',
      badge: 'Internal Admin',
      badgeColor: 'bg-purple-100 text-purple-800 border-purple-200',
      icon: ShieldCheck,
      iconBg: 'bg-purple-600 text-white',
      targetUser: 'QuickBlink City Ops & Executives',
      description: 'Citywide logistics monitor tracking live GMV, store commission rates, active riders, and dispatch health.',
      keyFeatures: [
        'Live citywide order dispatch matrix',
        'Real-time Gross Merchandise Value (GMV)',
        'Store commission rate editor (default 5%)',
        'Fleet availability and emergency cancel'
      ],
      accentColor: 'hover:border-purple-500'
    }
  ];

  const handleCopyLink = (roleId: Role, e: React.MouseEvent) => {
    e.stopPropagation();
    const url = `${getBaseUrl()}?view=${roleId}`;
    navigator.clipboard.writeText(url);
    setCopiedRole(roleId);
    setTimeout(() => setCopiedRole(null), 2500);
  };

  const handleOpenNewWindow = (roleId: Role, e: React.MouseEvent) => {
    e.stopPropagation();
    const url = `${getBaseUrl()}?view=${roleId}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full p-5 sm:p-7 shadow-2xl border border-slate-200 animate-in zoom-in-95 space-y-6 my-8">
        {/* Modal Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                <Cloud className="w-3 h-3 text-emerald-600" />
                Firebase Real-Time Synchronized
              </span>
              <span className="text-xs text-slate-400 font-medium hidden sm:inline">•</span>
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                4 Dedicated Portals
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Select App Portal or Open Separately
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Each persona has its own tailored user interface and business logic. Changes made in one panel sync live to the others.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 4-Screen Command Center Banner */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-2xl p-4 text-white flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-black flex items-center gap-2">
                <span>Want to see all 4 panels working simultaneously?</span>
                <span className="bg-emerald-500 text-slate-950 text-[9px] font-black uppercase px-2 py-0.5 rounded-md">
                  Recommended
                </span>
              </h4>
              <p className="text-[11.5px] text-slate-300">
                Turn on the <strong>4-Screen Command Center</strong> to display Customer, Store, Rider, and Admin side-by-side on this monitor.
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setIsMultiScreenMode(!isMultiScreenMode);
              onClose();
            }}
            className="w-full sm:w-auto px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl transition-all shadow-md shrink-0 flex items-center justify-center gap-1.5"
          >
            <Layers className="w-4 h-4" />
            <span>{isMultiScreenMode ? 'Exit Command Center' : 'Launch 4-Screen Center'}</span>
          </button>
        </div>

        {/* The 4 Dedicated App Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {portals.map((portal) => {
            const Icon = portal.icon;
            const isCurrent = role === portal.id && !isMultiScreenMode;

            return (
              <div
                key={portal.id}
                onClick={() => {
                  setRole(portal.id);
                  setIsMultiScreenMode(false);
                  onClose();
                }}
                className={`relative group p-4 sm:p-5 rounded-2xl border-2 cursor-pointer transition-all duration-200 text-left flex flex-col justify-between ${
                  isCurrent
                    ? 'border-emerald-600 bg-emerald-50/40 shadow-md ring-2 ring-emerald-500/20'
                    : `border-slate-200 bg-white hover:shadow-lg ${portal.accentColor}`
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl ${portal.iconBg} flex items-center justify-center shadow-xs shrink-0`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-base font-black text-slate-900 group-hover:text-emerald-700 transition-colors">
                          {portal.title}
                        </h3>
                        <span className="text-[11px] font-bold text-slate-400">
                          {portal.targetUser}
                        </span>
                      </div>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${portal.badgeColor} shrink-0`}>
                      {portal.badge}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed mb-3">
                    {portal.description}
                  </p>

                  <div className="space-y-1 mb-4 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    {portal.keyFeatures.map((feat, idx) => (
                      <div key={idx} className="flex items-center gap-1.5 text-[11px] text-slate-700">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={(e) => handleCopyLink(portal.id, e)}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-[11px] font-bold text-slate-700 flex items-center gap-1 transition-colors"
                      title="Copy direct shareable link for mobile or another device"
                    >
                      {copiedRole === portal.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span className="text-emerald-700">Link Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3 text-slate-500" />
                          <span>Copy Link</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={(e) => handleOpenNewWindow(portal.id, e)}
                      className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 transition-colors"
                      title="Open in a separate browser tab"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    onClick={() => {
                      setRole(portal.id);
                      setIsMultiScreenMode(false);
                      onClose();
                    }}
                    className={`px-3 py-1.5 rounded-lg font-black text-xs flex items-center gap-1 transition-all ${
                      isCurrent
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-slate-900 hover:bg-slate-800 text-white'
                    }`}
                  >
                    <span>{isCurrent ? 'Active View' : 'Open View'}</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer tip */}
        <div className="text-center pt-2">
          <p className="text-xs text-slate-400">
            💡 <strong>Pro-Tip:</strong> Copy the <strong>Customer App</strong> link to your mobile phone and keep the <strong>Kirana Store</strong> or <strong>Admin</strong> open on your laptop. Orders sync across both in real-time via Firestore!
          </p>
        </div>
      </div>
    </div>
  );
};
