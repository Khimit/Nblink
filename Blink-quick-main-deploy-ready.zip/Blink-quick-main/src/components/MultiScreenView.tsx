import React from 'react';
import { CustomerApp } from './Customer/CustomerApp';
import { ShopkeeperPortal } from './Shopkeeper/ShopkeeperPortal';
import { DeliveryApp } from './Delivery/DeliveryApp';
import { AdminPortal } from './Admin/AdminPortal';
import { useApp } from '../context/AppContext';
import {
  ShoppingBag,
  Store,
  Bike,
  ShieldCheck,
  Maximize2,
  X,
  Sparkles,
  Zap,
  Play
} from 'lucide-react';

export const MultiScreenView: React.FC = () => {
  const { setRole, setIsMultiScreenMode, triggerLiveSimulation, isSimulating } = useApp();

  return (
    <div className="p-3 sm:p-5 bg-slate-900 min-h-screen text-slate-100 flex flex-col space-y-4">
      {/* Command Center Control Bar */}
      <div className="bg-slate-950/80 border border-slate-800 rounded-2xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-lg backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shadow-md">
            <Zap className="w-5 h-5 fill-current" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-black text-white text-base tracking-tight">
                QuickBlink 4-Screen Ecosystem Command Center
              </h2>
              <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                LIVE INTERACTION
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Customer, Kirana Store, Delivery Rider, and Operations Admin syncing seamlessly
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* 1-Click Simulation Button */}
          <button
            onClick={triggerLiveSimulation}
            disabled={isSimulating}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-xl transition-all shadow-md disabled:opacity-50"
          >
            <Play className={`w-3.5 h-3.5 fill-current ${isSimulating ? 'animate-spin' : ''}`} />
            <span>{isSimulating ? 'Simulating Live...' : '⚡ Trigger 1-Click Cycle'}</span>
          </button>

          {/* Exit Multi-Screen */}
          <button
            onClick={() => setIsMultiScreenMode(false)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl border border-slate-700 transition-colors"
          >
            <X className="w-4 h-4" />
            <span>Close Command Center</span>
          </button>
        </div>
      </div>

      {/* 4 Quadrants Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 flex-1">
        {/* Panel 1: Customer View */}
        <div className="bg-slate-950 border border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-xl">
          <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2 text-emerald-400">
              <ShoppingBag className="w-4 h-4" />
              <span className="font-black text-xs uppercase tracking-wider text-white">
                1. Customer Shopping App
              </span>
            </div>
            <button
              onClick={() => {
                setRole('customer');
                setIsMultiScreenMode(false);
              }}
              className="text-[11px] text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-bold"
              title="Maximize Customer View"
            >
              <span>Maximize</span>
              <Maximize2 className="w-3 h-3" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto max-h-[700px] bg-slate-100 text-slate-900">
            <CustomerApp />
          </div>
        </div>

        {/* Panel 2: Kirana Shopkeeper View */}
        <div className="bg-slate-950 border border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-xl">
          <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2 text-blue-400">
              <Store className="w-4 h-4" />
              <span className="font-black text-xs uppercase tracking-wider text-white">
                2. Partner Kirana Store OS
              </span>
            </div>
            <button
              onClick={() => {
                setRole('shopkeeper');
                setIsMultiScreenMode(false);
              }}
              className="text-[11px] text-blue-400 hover:text-blue-300 flex items-center gap-1 font-bold"
              title="Maximize Shopkeeper View"
            >
              <span>Maximize</span>
              <Maximize2 className="w-3 h-3" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto max-h-[700px] bg-slate-100 text-slate-900">
            <ShopkeeperPortal />
          </div>
        </div>

        {/* Panel 3: Delivery Rider View */}
        <div className="bg-slate-950 border border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-xl">
          <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-400">
              <Bike className="w-4 h-4" />
              <span className="font-black text-xs uppercase tracking-wider text-white">
                3. Delivery Partner Cockpit
              </span>
            </div>
            <button
              onClick={() => {
                setRole('delivery');
                setIsMultiScreenMode(false);
              }}
              className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1 font-bold"
              title="Maximize Rider View"
            >
              <span>Maximize</span>
              <Maximize2 className="w-3 h-3" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto max-h-[700px] bg-slate-900 text-white">
            <DeliveryApp />
          </div>
        </div>

        {/* Panel 4: Admin Ops Tower */}
        <div className="bg-slate-950 border border-slate-800 rounded-3xl overflow-hidden flex flex-col shadow-xl">
          <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2 text-purple-400">
              <ShieldCheck className="w-4 h-4" />
              <span className="font-black text-xs uppercase tracking-wider text-white">
                4. Operations HQ Control Tower
              </span>
            </div>
            <button
              onClick={() => {
                setRole('admin');
                setIsMultiScreenMode(false);
              }}
              className="text-[11px] text-purple-400 hover:text-purple-300 flex items-center gap-1 font-bold"
              title="Maximize Admin View"
            >
              <span>Maximize</span>
              <Maximize2 className="w-3 h-3" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto max-h-[700px] bg-slate-100 text-slate-900">
            <AdminPortal />
          </div>
        </div>
      </div>
    </div>
  );
};
