import React, { useState } from 'react';
import {
  Zap,
  MapPin,
  ChevronDown,
  ShoppingBag,
  Store,
  Bike,
  ShieldCheck,
  Smartphone,
  Monitor,
  Play,
  Download,
  Bell,
  X,
  Volume2,
  QrCode,
  Layers,
  LayoutGrid
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Role } from '../types';
import { InstallModal } from './InstallModal';
import { AppPortalsModal } from './AppPortalsModal';

interface HeaderProps {
  onOpenPlayStoreModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenPlayStoreModal }) => {
  const {
    role,
    setRole,
    isMobileSimulator,
    setIsMobileSimulator,
    isMultiScreenMode,
    setIsMultiScreenMode,
    selectedAddress,
    setSelectedAddress,
    cart,
    orders,
    notificationBanner,
    clearNotification,
    triggerLiveSimulation,
    isSimulating
  } = useApp();

  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [addressInput, setAddressInput] = useState(selectedAddress);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [isPortalsModalOpen, setIsPortalsModalOpen] = useState(false);

  const cartItemsCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Unread badge counts per role
  const pendingShopOrders = orders.filter((o) => o.status === 'placed' || o.status === 'packing').length;
  const pendingRiderOrders = orders.filter((o) => o.status === 'packed' || o.status === 'assigned').length;

  const roleTabs: { id: Role; label: string; icon: React.ComponentType<{ className?: string }>; count?: number }[] = [
    { id: 'customer', label: 'Customer App', icon: ShoppingBag, count: cartItemsCount > 0 ? cartItemsCount : undefined },
    { id: 'shopkeeper', label: 'Kirana Store', icon: Store, count: pendingShopOrders > 0 ? pendingShopOrders : undefined },
    { id: 'delivery', label: 'Delivery Rider', icon: Bike, count: pendingRiderOrders > 0 ? pendingRiderOrders : undefined },
    { id: 'admin', label: 'Admin HQ', icon: ShieldCheck }
  ];

  return (
    <>
      {/* Alert Notification Toast Banner */}
      {notificationBanner && (
        <div
          id="role-notification-banner"
          className="bg-emerald-700 text-white px-4 py-2.5 shadow-md flex items-center justify-between text-xs sm:text-sm font-medium animate-in slide-in-from-top duration-300"
        >
          <div className="flex items-center gap-2 max-w-4xl mx-auto flex-1">
            <span className="p-1 bg-white/20 rounded-full animate-bounce">
              <Volume2 className="w-3.5 h-3.5" />
            </span>
            <span>{notificationBanner.message}</span>
            <button
              onClick={() => {
                setRole(notificationBanner.role);
                clearNotification();
              }}
              className="ml-2 underline font-bold hover:text-emerald-100 transition-colors"
            >
              Switch to {notificationBanner.role.toUpperCase()} View ➔
            </button>
          </div>
          <button
            onClick={clearNotification}
            className="p-1 hover:bg-white/20 rounded-md transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Global Topbar */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200/80 shadow-xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-6">
          <div className="flex items-center justify-between h-16 gap-3">
            {/* Logo & 10 Min Badge */}
            <div className="flex items-center gap-3">
              <div
                onClick={() => setRole('customer')}
                className="flex items-center gap-2 cursor-pointer select-none group"
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-green-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform">
                  <Zap className="w-5 h-5 fill-yellow-300 text-yellow-300" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-lg font-black tracking-tight text-slate-900">
                      Quick<span className="text-emerald-600">Blink</span>
                    </span>
                    <span className="bg-amber-400 text-amber-950 font-black text-[10px] px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                      10 MINS
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-medium hidden sm:block">
                    Kirana-to-Doorstep Hyperlocal
                  </p>
                </div>
              </div>

              {/* Delivery Address Pill (Customer) */}
              <button
                id="header-location-pill"
                onClick={() => setIsAddressModalOpen(true)}
                className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200/80 border border-slate-200 text-xs font-semibold text-slate-700 transition-colors text-left max-w-[220px]"
              >
                <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <div className="truncate">
                  <span className="text-slate-900 block font-bold leading-tight truncate">
                    {selectedAddress.area || 'Bellandur'}
                  </span>
                  <span className="text-[10px] text-slate-500 font-normal truncate block">
                    {selectedAddress.flatNo}, {selectedAddress.street}
                  </span>
                </div>
                <ChevronDown className="w-3 h-3 text-slate-400 shrink-0" />
              </button>
            </div>

            {/* Middle: Role Selector Tabs (Indian Quick Commerce Ecosystem) */}
            <nav className="hidden lg:flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
              {roleTabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = role === tab.id;
                return (
                  <button
                    key={tab.id}
                    id={`header-role-tab-${tab.id}`}
                    onClick={() => setRole(tab.id)}
                    className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      isActive
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/70'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{tab.label}</span>
                    {tab.count !== undefined && (
                      <span
                        className={`text-[10px] font-black px-1.5 py-0.2 rounded-full ${
                          isActive
                            ? 'bg-white text-emerald-700'
                            : 'bg-emerald-600 text-white animate-pulse'
                        }`}
                      >
                        {tab.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Right Action Tools: Portals Hub + 4-Screen Center + 1-Click Demo + Frame Mode + Play Store Modal */}
            <div className="flex items-center gap-2">
              {/* App Portals Hub Switcher */}
              <button
                id="btn-open-portals-hub"
                onClick={() => setIsPortalsModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-600/30 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-black transition-all hover:scale-102"
                title="Switch between Customer, Kirana Store, Delivery Boy, and Admin Portals"
              >
                <LayoutGrid className="w-3.5 h-3.5 text-emerald-700" />
                <span className="hidden md:inline">Portals Hub</span>
              </button>

              {/* 4-Screen Simultaneous Center */}
              <button
                id="btn-toggle-4screen-mode"
                onClick={() => setIsMultiScreenMode(!isMultiScreenMode)}
                className={`hidden xl:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-black transition-all ${
                  isMultiScreenMode
                    ? 'bg-purple-600 text-white border-purple-600 shadow-sm'
                    : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
                title="View all 4 applications (Customer, Store, Rider, Admin) simultaneously"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>{isMultiScreenMode ? 'Exit 4-Screen' : '4-Screen View'}</span>
              </button>

              {/* 1-Click End-to-End Walkthrough */}
              <button
                id="btn-live-simulation"
                onClick={triggerLiveSimulation}
                disabled={isSimulating}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-600 hover:to-yellow-500 text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-all hover:scale-102 disabled:opacity-50"
                title="Watch the full lifecycle from Customer Order -> Shopkeeper Packing -> Delivery Boy Pickup -> OTP Delivery in real-time"
              >
                <Play className={`w-3.5 h-3.5 fill-current ${isSimulating ? 'animate-spin' : ''}`} />
                <span className="hidden sm:inline">
                  {isSimulating ? 'Simulating Live...' : '⚡ 1-Click Demo'}
                </span>
              </button>

              {/* Mobile Phone Frame Toggle */}
              <button
                id="btn-toggle-frame-mode"
                onClick={() => setIsMobileSimulator(!isMobileSimulator)}
                className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1 transition-colors ${
                  isMobileSimulator
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
                title={isMobileSimulator ? 'Switch to Fullscreen Responsive View' : 'Switch to Android Mobile Device Simulator'}
              >
                {isMobileSimulator ? (
                  <Monitor className="w-4 h-4" />
                ) : (
                  <Smartphone className="w-4 h-4 text-emerald-600" />
                )}
                <span className="hidden xl:inline">
                  {isMobileSimulator ? 'Desktop' : 'Android App View'}
                </span>
              </button>

              {/* Install / Test on Mobile QR Tool */}
              <button
                id="btn-install-mobile-modal"
                onClick={() => setIsInstallModalOpen(true)}
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border border-emerald-500/50 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-xs transition-all hover:scale-102"
                title="Scan QR or open directly on your Android / iPhone"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">📲 Test on Mobile</span>
                <span className="sm:hidden">Install</span>
              </button>

              {/* Play Store TWA Export Kit */}
              <button
                id="btn-playstore-ready"
                onClick={onOpenPlayStoreModal}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Play Store Ready</span>
              </button>
            </div>
          </div>

          {/* Mobile sub-bar for Role Switcher on small screens */}
          <div className="lg:hidden flex items-center justify-between overflow-x-auto py-2 border-t border-slate-100 no-scrollbar gap-1">
            {roleTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = role === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setRole(tab.id)}
                  className={`flex-1 min-w-[75px] py-1 px-1.5 rounded-lg text-[11px] font-bold flex flex-col items-center gap-1 transition-colors ${
                    isActive ? 'bg-emerald-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <div className="relative">
                    <Icon className="w-3.5 h-3.5" />
                    {tab.count !== undefined && (
                      <span className="absolute -top-1 -right-2 bg-amber-400 text-amber-950 font-black text-[9px] px-1 rounded-full">
                        {tab.count}
                      </span>
                    )}
                  </div>
                  <span className="whitespace-nowrap truncate max-w-[80px]">{tab.label.split(' ')[0]}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Address Edit Modal */}
      {isAddressModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">Select Delivery Address</h3>
              </div>
              <button
                onClick={() => setIsAddressModalOpen(false)}
                className="p-1 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-600">Flat / House / Floor No.</label>
                <input
                  type="text"
                  value={addressInput.flatNo}
                  onChange={(e) => setAddressInput({ ...addressInput, flatNo: e.target.value })}
                  className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  placeholder="e.g. Flat 402, Tower B"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-600">Apartment / Society / Street</label>
                <input
                  type="text"
                  value={addressInput.street}
                  onChange={(e) => setAddressInput({ ...addressInput, street: e.target.value })}
                  className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  placeholder="e.g. Green Glen Layout, Bellandur"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600">Area / Locality</label>
                  <input
                    type="text"
                    value={addressInput.area}
                    onChange={(e) => setAddressInput({ ...addressInput, area: e.target.value })}
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    placeholder="e.g. Bellandur"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600">Pin Code</label>
                  <input
                    type="text"
                    value={addressInput.pinCode}
                    onChange={(e) => setAddressInput({ ...addressInput, pinCode: e.target.value })}
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    placeholder="560103"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-600">Nearby Landmark</label>
                <input
                  type="text"
                  value={addressInput.landmark}
                  onChange={(e) => setAddressInput({ ...addressInput, landmark: e.target.value })}
                  className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  placeholder="e.g. Near Cult.Fit / Central Mall"
                />
              </div>

              <div className="pt-2">
                <button
                  onClick={() => {
                    setSelectedAddress(addressInput);
                    setIsAddressModalOpen(false);
                  }}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-colors text-sm"
                >
                  Save & Deliver Here (10 Mins ETA)
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Install & QR Guide Modal */}
      <InstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />

      {/* 4 Dedicated App Portals Hub Modal */}
      <AppPortalsModal
        isOpen={isPortalsModalOpen}
        onClose={() => setIsPortalsModalOpen(false)}
      />
    </>
  );
};
