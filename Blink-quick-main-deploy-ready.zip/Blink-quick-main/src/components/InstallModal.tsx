import React, { useState } from 'react';
import {
  X,
  Smartphone,
  CheckCircle2,
  Copy,
  Check,
  QrCode,
  AlertTriangle,
  Download,
  ExternalLink,
  HelpCircle,
  Sparkles
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://ais-pre-ftawgxajh4px44b2vmo74h-940101671865.asia-east1.run.app';
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=10&data=${encodeURIComponent(currentUrl)}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 space-y-5">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-slate-900 text-base">
                Install QuickBlink on Your Mobile
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                Test UI, cart, live tracking, and packing workflows on your phone
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 1-Tap In-App Install Button if browser supports it */}
        {isInstallable && (
          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-center space-y-2">
            <span className="text-xs font-bold text-emerald-800">
              Your browser supports direct 1-tap installation!
            </span>
            <button
              onClick={install}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>Tap Here to Install App on This Device</span>
            </button>
          </div>
        )}

        {/* Notice explaining PWABuilder & direct website behavior */}
        <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200 text-xs text-amber-900 space-y-1.5">
          <div className="flex items-center gap-1.5 font-black text-amber-950">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>Why PWABuilder or Direct Phone Link Showed an Issue:</span>
          </div>
          <p className="text-[11.5px] leading-relaxed text-amber-900/90">
            This AI Studio preview URL is protected by Google Cloud security. External bot tools like <strong>PWABuilder cannot access it</strong> because they lack your Google login session. To open it on your phone:
          </p>
        </div>

        {/* Step-by-Step Instructions */}
        <div className="space-y-3 text-xs">
          <div className="font-extrabold text-slate-900 uppercase tracking-wider text-[11px]">
            Follow These 3 Simple Steps on Your Phone:
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* QR Code */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col items-center justify-center text-center">
              <img
                src={qrCodeUrl}
                alt="QuickBlink Mobile QR Code"
                className="w-36 h-36 rounded-xl border border-slate-200 bg-white p-1 shadow-xs"
              />
              <span className="text-[10px] font-bold text-slate-500 mt-2">
                1. Scan with Phone Camera
              </span>
            </div>

            {/* Steps Guide */}
            <div className="space-y-2 text-[11px] text-slate-700 flex flex-col justify-center">
              <div className="p-2 rounded-xl bg-slate-50 border border-slate-100">
                <strong className="text-slate-900 block">Step 1: Sign in with your Google Account</strong>
                Make sure the Chrome browser on your phone is logged into the same email: <span className="font-mono text-emerald-700 font-bold">sanketpatil19991810@gmail.com</span>.
              </div>

              <div className="p-2 rounded-xl bg-slate-50 border border-slate-100">
                <strong className="text-slate-900 block">Step 2: Add to Home Screen</strong>
                In Chrome, tap the <strong>three dots (⋮)</strong> at top-right ➔ tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.
              </div>

              <div className="p-2 rounded-xl bg-slate-50 border border-slate-100">
                <strong className="text-slate-900 block">Step 3: Launch Native Fullscreen</strong>
                QuickBlink will launch with an app icon on your phone without the browser URL bar!
              </div>
            </div>
          </div>
        </div>

        {/* Copy Direct URL */}
        <div className="p-3 bg-slate-100 rounded-2xl border border-slate-200 flex items-center justify-between gap-2 text-xs">
          <div className="truncate font-mono text-[11px] text-slate-600 select-all">
            {currentUrl}
          </div>
          <button
            onClick={handleCopy}
            className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-800 font-bold rounded-xl border border-slate-200 shrink-0 flex items-center gap-1.5 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied Link' : 'Copy URL'}</span>
          </button>
        </div>

        {/* Alternative: In-Browser Android Simulator */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
          <span className="text-slate-500 text-[11px]">
            Want to test right now on this screen?
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs transition-colors"
          >
            Got it, Close
          </button>
        </div>
      </div>
    </div>
  );
};
