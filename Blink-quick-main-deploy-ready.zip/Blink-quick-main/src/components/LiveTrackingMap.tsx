import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface LiveTrackingMapProps {
  shopLat: number;
  shopLng: number;
  shopName: string;
  customerLat: number;
  customerLng: number;
  customerLabel: string;
  riderLat?: number;
  riderLng?: number;
  riderName?: string;
}

// Small colored pin icons built from divs so we don't need external image assets.
function pinIcon(bg: string, emoji: string) {
  return L.divIcon({
    className: '',
    html: `<div style="
      width:34px;height:34px;border-radius:50% 50% 50% 0;
      background:${bg};transform:rotate(-45deg);
      display:flex;align-items:center;justify-content:center;
      box-shadow:0 2px 6px rgba(0,0,0,0.35);border:2px solid white;
    "><span style="transform:rotate(45deg);font-size:16px;">${emoji}</span></div>`,
    iconSize: [34, 34],
    iconAnchor: [17, 34]
  });
}

/**
 * Renders a real OpenStreetMap-based map (no API key required) showing the
 * store, the customer's doorstep, and — while an order is out for delivery —
 * the rider's live GPS position, updated in real time via Firestore.
 */
export const LiveTrackingMap: React.FC<LiveTrackingMapProps> = ({
  shopLat,
  shopLng,
  shopName,
  customerLat,
  customerLng,
  customerLabel,
  riderLat,
  riderLng,
  riderName = 'Delivery partner'
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const riderMarkerRef = useRef<L.Marker | null>(null);
  const routeLineRef = useRef<L.Polyline | null>(null);

  // Initialize the map once.
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      zoomControl: true,
      attributionControl: true
    }).setView([shopLat, shopLng], 14);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19
    }).addTo(map);

    L.marker([shopLat, shopLng], { icon: pinIcon('#059669', '🏪') })
      .addTo(map)
      .bindPopup(shopName);

    L.marker([customerLat, customerLng], { icon: pinIcon('#2563eb', '🏠') })
      .addTo(map)
      .bindPopup(customerLabel);

    const bounds = L.latLngBounds([
      [shopLat, shopLng],
      [customerLat, customerLng]
    ]);
    map.fitBounds(bounds, { padding: [40, 40] });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shopLat, shopLng, customerLat, customerLng]);

  // Add / move the rider marker whenever a live position comes in.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || riderLat === undefined || riderLng === undefined) return;

    if (!riderMarkerRef.current) {
      riderMarkerRef.current = L.marker([riderLat, riderLng], {
        icon: pinIcon('#f97316', '🛵')
      })
        .addTo(map)
        .bindPopup(riderName);
    } else {
      riderMarkerRef.current.setLatLng([riderLat, riderLng]);
    }

    if (routeLineRef.current) {
      routeLineRef.current.remove();
    }
    routeLineRef.current = L.polyline(
      [
        [riderLat, riderLng],
        [customerLat, customerLng]
      ],
      { color: '#f97316', dashArray: '6 6', weight: 3 }
    ).addTo(map);

    const bounds = L.latLngBounds([
      [riderLat, riderLng],
      [customerLat, customerLng],
      [shopLat, shopLng]
    ]);
    map.fitBounds(bounds, { padding: [50, 50], maxZoom: 16 });
  }, [riderLat, riderLng, riderName, customerLat, customerLng, shopLat, shopLng]);

  return (
    <div className="w-full rounded-2xl overflow-hidden border border-slate-200 shadow-sm relative">
      <div ref={containerRef} style={{ height: 240, width: '100%' }} />
      {riderLat === undefined && (
        <div className="absolute inset-0 bg-white/70 backdrop-blur-[1px] flex items-center justify-center text-xs font-bold text-slate-500 pointer-events-none">
          Waiting for delivery partner's live location…
        </div>
      )}
    </div>
  );
};
