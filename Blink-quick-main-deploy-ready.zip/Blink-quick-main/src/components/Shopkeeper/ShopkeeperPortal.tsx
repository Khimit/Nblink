import React, { useState } from 'react';
import {
  Store,
  Package,
  PlusCircle,
  CheckCircle2,
  Clock,
  DollarSign,
  Settings,
  Bell,
  CheckSquare,
  Square,
  Bike,
  Phone,
  MapPin,
  TrendingUp,
  AlertCircle,
  ToggleLeft,
  ToggleRight,
  Trash2,
  Edit2,
  X,
  Volume2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Product, Shop } from '../../types';

export const ShopkeeperPortal: React.FC = () => {
  const {
    shops,
    activeShopId,
    setActiveShopId,
    products,
    orders,
    acceptOrder,
    toggleItemPacked,
    markOrderPacked,
    addProduct,
    updateProduct,
    deleteProduct,
    updateShopSettings,
    onboardNewShop,
    setRole
  } = useApp();

  const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'payouts' | 'profile'>('orders');
  const [orderFilter, setOrderFilter] = useState<'all' | 'new' | 'packing' | 'packed' | 'completed'>('all');

  // Add Product Modal state
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: '',
    category: 'Dairy & Bread',
    brand: '',
    unit: '500 g',
    mrp: 50,
    price: 45,
    stockCount: 30,
    imageUrl: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=500&auto=format&fit=crop&q=80',
    description: ''
  });

  // Onboard Shop Modal
  const [isOnboardShopOpen, setIsOnboardShopOpen] = useState(false);
  const [onboardForm, setOnboardForm] = useState({
    name: '',
    ownerName: '',
    phone: '',
    upiId: '',
    address: '',
    area: '',
    distanceKm: 1.2,
    // Default to a central Bengaluru point until real address geocoding is added.
    lat: 12.9279,
    lng: 77.6271,
    isOpen: true,
    commissionPercent: 5,
    bannerUrl: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=800&auto=format&fit=crop&q=80',
    categories: ['Dairy & Bread', 'Fresh Veggies', 'Snacks & Munchies', 'Daily Staples']
  });

  const currentShop = shops.find((s) => s.id === activeShopId) || shops[0];

  // Orders for current shop
  const shopOrders = orders.filter((o) => o.shopId === currentShop.id);
  const filteredOrders = shopOrders.filter((o) => {
    if (orderFilter === 'all') return true;
    if (orderFilter === 'new') return o.status === 'placed';
    if (orderFilter === 'packing') return o.status === 'packing';
    if (orderFilter === 'packed') return o.status === 'packed';
    if (orderFilter === 'completed') return o.status === 'delivered';
    return true;
  });

  const shopProducts = products.filter((p) => p.shopId === currentShop.id || !p.shopId);

  // Financial calculations
  const totalRevenue = shopOrders
    .filter((o) => o.status !== 'cancelled')
    .reduce((sum, o) => sum + o.bill.itemTotal, 0);
  const commissionDeducted = Math.round((totalRevenue * currentShop.commissionPercent) / 100);
  const netEarnings = totalRevenue - commissionDeducted;

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.name) return;

    const discount = Math.round(((newProduct.mrp - newProduct.price) / newProduct.mrp) * 100);

    addProduct({
      shopId: currentShop.id,
      name: newProduct.name,
      category: newProduct.category,
      brand: newProduct.brand || currentShop.name.split(' ')[0],
      unit: newProduct.unit,
      mrp: Number(newProduct.mrp),
      price: Number(newProduct.price),
      discountPercent: discount > 0 ? discount : 0,
      inStock: true,
      stockCount: Number(newProduct.stockCount),
      imageUrl: newProduct.imageUrl,
      description: newProduct.description || `${newProduct.name} fresh stock from ${currentShop.name}`
    });

    setIsAddProductOpen(false);
    setNewProduct({
      name: '',
      category: 'Dairy & Bread',
      brand: '',
      unit: '500 g',
      mrp: 50,
      price: 45,
      stockCount: 30,
      imageUrl: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=500&auto=format&fit=crop&q=80',
      description: ''
    });
  };

  const handleOnboardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onboardForm.name || !onboardForm.ownerName) return;
    onboardNewShop(onboardForm);
    setIsOnboardShopOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Storekeeper Profile & Stats Header */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-700 text-white flex items-center justify-center shadow-md shadow-emerald-700/20">
              <Store className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-black text-slate-900 tracking-tight">
                  {currentShop.name}
                </h1>
                <span className="bg-emerald-100 text-emerald-800 text-xs font-black px-2 py-0.5 rounded-full">
                  Partner Kirana
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Owner: <strong>{currentShop.ownerName}</strong> • UPI Payout:{' '}
                <span className="font-mono text-emerald-700 font-bold">{currentShop.upiId}</span>
              </p>
            </div>
          </div>

          {/* Quick Actions & Store Status Toggle */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Store Open / Closed Toggle */}
            <button
              id="btn-toggle-store-open"
              onClick={() =>
                updateShopSettings(currentShop.id, { isOpen: !currentShop.isOpen })
              }
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all ${
                currentShop.isOpen
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                  : 'bg-rose-50 text-rose-800 border-rose-300'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  currentShop.isOpen ? 'bg-emerald-600 animate-ping' : 'bg-rose-600'
                }`}
              />
              <span>{currentShop.isOpen ? 'Store OPEN for Orders' : 'Store CLOSED'}</span>
            </button>

            {/* Select Shop */}
            <select
              value={activeShopId}
              onChange={(e) => setActiveShopId(e.target.value)}
              className="px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700"
            >
              {shops.map((s) => (
                <option key={s.id} value={s.id}>
                  Switch Store: {s.name}
                </option>
              ))}
            </select>

            {/* Onboard New Partner Shop */}
            <button
              id="btn-onboard-partner-shop"
              onClick={() => setIsOnboardShopOpen(true)}
              className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              + Onboard New Shop
            </button>
          </div>
        </div>

        {/* Quick KPI Overview */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-5 border-t border-slate-100">
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
            <span className="text-[11px] font-bold text-slate-400 uppercase">Incoming / Active</span>
            <div className="text-xl font-black text-slate-900 mt-0.5">
              {shopOrders.filter((o) => o.status !== 'delivered' && o.status !== 'cancelled').length} Orders
            </div>
          </div>
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
            <span className="text-[11px] font-bold text-slate-400 uppercase">Catalog Products</span>
            <div className="text-xl font-black text-emerald-700 mt-0.5">
              {shopProducts.length} Items
            </div>
          </div>
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
            <span className="text-[11px] font-bold text-slate-400 uppercase">Gross Sales (GMV)</span>
            <div className="text-xl font-black text-slate-900 mt-0.5">
              ₹{totalRevenue}
            </div>
          </div>
          <div className="bg-emerald-50 p-3 rounded-2xl border border-emerald-100">
            <span className="text-[11px] font-bold text-emerald-800 uppercase">Net Payout (After 5%)</span>
            <div className="text-xl font-black text-emerald-900 mt-0.5">
              ₹{netEarnings}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        {[
          { id: 'orders', label: 'Live Orders Queue', icon: Package, count: shopOrders.filter((o) => o.status === 'placed' || o.status === 'packing').length },
          { id: 'products', label: 'Catalog & Add Products', icon: PlusCircle, count: shopProducts.length },
          { id: 'payouts', label: 'Earnings & UPI Settlements', icon: DollarSign },
          { id: 'profile', label: 'Shop Details & Onboarding', icon: Settings }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-extrabold transition-all ${
                isActive
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.count !== undefined && tab.count > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                    isActive ? 'bg-white text-emerald-800' : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: LIVE ORDERS QUEUE */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {/* Filters */}
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              {[
                { id: 'all', label: 'All Orders' },
                { id: 'new', label: 'New Unpacked' },
                { id: 'packing', label: 'In-Packing' },
                { id: 'packed', label: 'Ready for Rider' },
                { id: 'completed', label: 'Delivered' }
              ].map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setOrderFilter(filter.id as typeof orderFilter)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                    orderFilter === filter.id
                      ? 'bg-slate-900 text-white'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>

            <span className="text-xs font-semibold text-slate-500">
              Showing {filteredOrders.length} orders
            </span>
          </div>

          {filteredOrders.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
              <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="font-bold text-slate-800 text-base">No Orders in this Status</h3>
              <p className="text-xs text-slate-400 mt-1">
                When customers place grocery orders on QuickBlink, they will appear here in real-time with an alert chime.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredOrders.map((order) => {
                const allItemsPacked = order.items.every((i) => i.isPacked);

                return (
                  <div
                    key={order.id}
                    className={`bg-white rounded-3xl p-5 border transition-all shadow-xs ${
                      order.status === 'placed'
                        ? 'border-amber-400 ring-2 ring-amber-200/50 bg-amber-50/20'
                        : order.status === 'packing'
                        ? 'border-emerald-300'
                        : 'border-slate-200'
                    }`}
                  >
                    {/* Card Top */}
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-sm text-slate-900">
                            #{order.orderNumber}
                          </span>
                          <span
                            className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                              order.status === 'placed'
                                ? 'bg-amber-100 text-amber-900 animate-pulse'
                                : order.status === 'packing'
                                ? 'bg-blue-100 text-blue-900'
                                : order.status === 'packed'
                                ? 'bg-purple-100 text-purple-900'
                                : order.status === 'delivered'
                                ? 'bg-emerald-100 text-emerald-900'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {order.status.replace('_', ' ')}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-medium">
                          Paid ₹{order.bill.grandTotal} via {order.payment.method.toUpperCase()}
                        </span>
                      </div>

                      <div className="text-right">
                        <span className="text-xs font-bold text-slate-800 block">
                          {order.customerName}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {order.customerAddress.flatNo}, {order.customerAddress.area}
                        </span>
                      </div>
                    </div>

                    {/* Interactive Packing Checklist */}
                    <div className="py-3 space-y-2">
                      <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                        Item Checklist (Tick as you put in bag):
                      </span>

                      <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                        {order.items.map((item) => (
                          <div
                            key={item.productId}
                            onClick={() => toggleItemPacked(order.id, item.productId)}
                            className={`flex items-center justify-between p-2 rounded-xl border text-xs cursor-pointer select-none transition-colors ${
                              item.isPacked
                                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              {item.isPacked ? (
                                <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                              ) : (
                                <Square className="w-4 h-4 text-slate-400 shrink-0" />
                              )}
                              <span className={item.isPacked ? 'line-through text-slate-400 font-medium' : 'font-bold'}>
                                {item.quantity}x {item.name} ({item.unit})
                              </span>
                            </div>
                            <span className="font-bold">₹{item.price * item.quantity}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Assigned Rider Info (if any) */}
                    {order.deliveryPartner && (
                      <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs mb-3">
                        <div className="flex items-center gap-2">
                          <Bike className="w-4 h-4 text-emerald-600" />
                          <span className="font-bold text-slate-800">
                            Rider: {order.deliveryPartner.name} ({order.deliveryPartner.vehicleNumber})
                          </span>
                        </div>
                        <a
                          href={`tel:${order.deliveryPartner.phone}`}
                          className="text-emerald-700 font-bold hover:underline"
                        >
                          Call Rider
                        </a>
                      </div>
                    )}

                    {/* Order Action Buttons */}
                    <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                      {order.status === 'placed' && (
                        <button
                          id={`btn-accept-order-${order.id}`}
                          onClick={() => acceptOrder(order.id)}
                          className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors"
                        >
                          Accept & Start Packing
                        </button>
                      )}

                      {order.status === 'packing' && (
                        <button
                          id={`btn-mark-packed-${order.id}`}
                          onClick={() => markOrderPacked(order.id)}
                          className="flex-1 py-2.5 bg-purple-700 hover:bg-purple-800 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-colors"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Mark Packed & Call Delivery Boy</span>
                        </button>
                      )}

                      {order.status === 'packed' && (
                        <div className="flex-1 py-2 px-3 bg-purple-50 text-purple-900 border border-purple-200 rounded-xl text-xs font-bold flex items-center justify-between">
                          <span className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-purple-600 animate-ping"></span>
                            Waiting for Delivery Boy Pickup
                          </span>
                          <button
                            onClick={() => setRole('delivery')}
                            className="text-purple-700 underline font-extrabold text-[11px]"
                          >
                            Switch to Rider ➔
                          </button>
                        </div>
                      )}

                      {order.status === 'delivered' && (
                        <div className="flex-1 py-2 px-3 bg-emerald-50 text-emerald-900 rounded-xl text-xs font-bold flex items-center justify-center gap-1">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <span>Delivered & Settled</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: PRODUCT CATALOG & ADD PRODUCTS */}
      {activeTab === 'products' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">
                Store Inventory & Products
              </h3>
              <p className="text-xs text-slate-500">
                Products listed here are visible to customers in your delivery radius.
              </p>
            </div>

            <button
              id="btn-open-add-product-modal"
              onClick={() => setIsAddProductOpen(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Add New Product</span>
            </button>
          </div>

          {/* Products Table */}
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200 uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="p-3.5">Product</th>
                    <th className="p-3.5">Category</th>
                    <th className="p-3.5">Unit</th>
                    <th className="p-3.5">MRP / Price</th>
                    <th className="p-3.5">Stock</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {shopProducts.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="p-3.5">
                        <div className="flex items-center gap-3">
                          <img
                            src={p.imageUrl}
                            alt={p.name}
                            className="w-10 h-10 object-contain rounded-lg bg-slate-100 p-1 shrink-0"
                          />
                          <div>
                            <span className="font-bold text-slate-900 block">{p.name}</span>
                            <span className="text-[10px] text-slate-400 uppercase font-semibold">
                              {p.brand}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="p-3.5 font-medium">{p.category}</td>
                      <td className="p-3.5 font-bold">{p.unit}</td>
                      <td className="p-3.5">
                        <span className="font-black text-slate-900">₹{p.price}</span>
                        {p.mrp > p.price && (
                          <span className="text-slate-400 line-through ml-1.5">₹{p.mrp}</span>
                        )}
                      </td>
                      <td className="p-3.5">
                        <input
                          type="number"
                          value={p.stockCount}
                          onChange={(e) =>
                            updateProduct(p.id, { stockCount: Number(e.target.value) })
                          }
                          className="w-16 px-2 py-1 bg-slate-100 border border-slate-200 rounded-lg text-xs font-bold text-slate-800"
                        />
                      </td>
                      <td className="p-3.5">
                        <button
                          onClick={() => updateProduct(p.id, { inStock: !p.inStock })}
                          className={`px-2.5 py-1 rounded-full font-bold text-[10px] uppercase transition-colors ${
                            p.inStock
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {p.inStock ? 'In Stock' : 'Out of Stock'}
                        </button>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => deleteProduct(p.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                          title="Remove Product"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: SETTLEMENTS & PAYOUTS */}
      {activeTab === 'payouts' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-base">
              Merchant Settlements & Commission
            </h3>
            <p className="text-xs text-slate-500 max-w-xl">
              QuickBlink operates on a low 5% platform commission model for kiranas. Payouts are directly settled to your UPI ID daily or on-demand.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <span className="text-xs font-bold text-slate-500">Gross Sales Value</span>
                <div className="text-2xl font-black text-slate-900 mt-1">₹{totalRevenue}</div>
                <span className="text-[10px] text-slate-400">Total customer orders</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <span className="text-xs font-bold text-slate-500">
                  Platform Commission ({currentShop.commissionPercent}%)
                </span>
                <div className="text-2xl font-black text-rose-600 mt-1">-₹{commissionDeducted}</div>
                <span className="text-[10px] text-slate-400">Tech & delivery fee shared</span>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
                <span className="text-xs font-bold text-emerald-800">Available Net Settlement</span>
                <div className="text-2xl font-black text-emerald-900 mt-1">₹{netEarnings}</div>
                <span className="text-[10px] text-emerald-700 font-bold">Direct to {currentShop.upiId}</span>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between flex-wrap gap-3">
              <div className="text-xs text-slate-600">
                Registered Bank UPI Handle:{' '}
                <strong className="font-mono text-slate-900">{currentShop.upiId}</strong>
              </div>
              <button
                onClick={() => alert(`₹${netEarnings} payout initiated to ${currentShop.upiId} via IMPS/UPI!`)}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors"
              >
                Instant UPI Payout Transfer ➔
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SHOP PROFILE & ONBOARDING */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4 max-w-2xl">
          <h3 className="font-extrabold text-slate-900 text-base">Store Profile & Settings</h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="font-bold text-slate-700">Store Name</label>
              <input
                type="text"
                value={currentShop.name}
                onChange={(e) => updateShopSettings(currentShop.id, { name: e.target.value })}
                className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700">Owner Name</label>
              <input
                type="text"
                value={currentShop.ownerName}
                onChange={(e) => updateShopSettings(currentShop.id, { ownerName: e.target.value })}
                className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700">Contact Phone</label>
                <input
                  type="text"
                  value={currentShop.phone}
                  onChange={(e) => updateShopSettings(currentShop.id, { phone: e.target.value })}
                  className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl font-semibold text-slate-800"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700">Merchant UPI ID (for Payouts)</label>
                <input
                  type="text"
                  value={currentShop.upiId}
                  onChange={(e) => updateShopSettings(currentShop.id, { upiId: e.target.value })}
                  className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl font-mono text-emerald-800 font-bold"
                />
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700">Physical Store Address</label>
              <input
                type="text"
                value={currentShop.address}
                onChange={(e) => updateShopSettings(currentShop.id, { address: e.target.value })}
                className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl font-medium text-slate-800"
              />
            </div>
          </div>
        </div>
      )}

      {/* Add Product Modal */}
      {isAddProductOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-emerald-600" />
                <h3 className="font-extrabold text-slate-900 text-base">Add New Product to Store</h3>
              </div>
              <button onClick={() => setIsAddProductOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700">Product Title / Item Name</label>
                <input
                  type="text"
                  required
                  value={newProduct.name}
                  onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                  placeholder="e.g. Amul Pure Ghee 1L Tin"
                  className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700">Category</label>
                  <select
                    value={newProduct.category}
                    onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs font-bold"
                  >
                    <option value="Dairy & Bread">Dairy & Bread</option>
                    <option value="Fresh Veggies">Fresh Veggies</option>
                    <option value="Snacks & Munchies">Snacks & Munchies</option>
                    <option value="Instant Foods">Instant Foods</option>
                    <option value="Drinks & Juices">Drinks & Juices</option>
                    <option value="Daily Staples">Daily Staples</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700">Brand Name</label>
                  <input
                    type="text"
                    value={newProduct.brand}
                    onChange={(e) => setNewProduct({ ...newProduct, brand: e.target.value })}
                    placeholder="e.g. Amul, Britannia, Nestle"
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-700">Weight / Unit</label>
                  <input
                    type="text"
                    required
                    value={newProduct.unit}
                    onChange={(e) => setNewProduct({ ...newProduct, unit: e.target.value })}
                    placeholder="500 g / 1 L"
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700">MRP (₹)</label>
                  <input
                    type="number"
                    required
                    value={newProduct.mrp}
                    onChange={(e) => setNewProduct({ ...newProduct, mrp: Number(e.target.value) })}
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700">Selling Price (₹)</label>
                  <input
                    type="number"
                    required
                    value={newProduct.price}
                    onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })}
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs font-bold text-emerald-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700">Stock Count</label>
                  <input
                    type="number"
                    value={newProduct.stockCount}
                    onChange={(e) => setNewProduct({ ...newProduct, stockCount: Number(e.target.value) })}
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700">Photo URL</label>
                  <input
                    type="url"
                    value={newProduct.imageUrl}
                    onChange={(e) => setNewProduct({ ...newProduct, imageUrl: e.target.value })}
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl shadow-md transition-colors text-xs uppercase tracking-wider"
                >
                  Publish to Live Catalog (Instant Customer Visibility)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Onboard New Shop Modal */}
      {isOnboardShopOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Store className="w-5 h-5 text-emerald-600" />
                <h3 className="font-extrabold text-slate-900 text-base">Onboard New Partner Kirana</h3>
              </div>
              <button onClick={() => setIsOnboardShopOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleOnboardSubmit} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700">Kirana Store Name</label>
                <input
                  type="text"
                  required
                  value={onboardForm.name}
                  onChange={(e) => setOnboardForm({ ...onboardForm, name: e.target.value })}
                  placeholder="e.g. Mahalakshmi Provision Store"
                  className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700">Owner Name</label>
                <input
                  type="text"
                  required
                  value={onboardForm.ownerName}
                  onChange={(e) => setOnboardForm({ ...onboardForm, ownerName: e.target.value })}
                  placeholder="e.g. Suresh Patel"
                  className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700">Phone</label>
                  <input
                    type="text"
                    required
                    value={onboardForm.phone}
                    onChange={(e) => setOnboardForm({ ...onboardForm, phone: e.target.value })}
                    placeholder="+91 98765 00000"
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700">Merchant UPI ID</label>
                  <input
                    type="text"
                    required
                    value={onboardForm.upiId}
                    onChange={(e) => setOnboardForm({ ...onboardForm, upiId: e.target.value })}
                    placeholder="shopname@okhdfcbank"
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700">Shop Address & Landmark</label>
                <input
                  type="text"
                  required
                  value={onboardForm.address}
                  onChange={(e) => setOnboardForm({ ...onboardForm, address: e.target.value })}
                  placeholder="Main Bazaar Road, Near Bus Stand"
                  className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl shadow-md transition-colors text-xs"
                >
                  Onboard & Activate Partner Store
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
