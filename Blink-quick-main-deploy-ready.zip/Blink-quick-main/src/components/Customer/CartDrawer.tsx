import React, { useState } from 'react';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShieldCheck,
  Zap,
  ArrowRight,
  Lock,
  Banknote,
  CreditCard,
  Loader2,
  AlertTriangle
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PaymentDetails } from '../../types';

declare global {
  interface Window {
    Razorpay: any;
  }
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderSuccess: (orderId: string) => void;
}

// Loads the Razorpay checkout script once and reuses it on subsequent opens.
function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const existing = document.getElementById('razorpay-checkout-js');
    if (existing) {
      existing.addEventListener('load', () => resolve(true));
      existing.addEventListener('error', () => resolve(false));
      return;
    }
    const script = document.createElement('script');
    script.id = 'razorpay-checkout-js';
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  onOrderSuccess
}) => {
  const {
    cart,
    updateCartQuantity,
    clearCart,
    selectedAddress,
    placeOrder,
    shops,
    activeShopId
  } = useApp();

  const [tip, setTip] = useState<number>(10);
  const [paymentMethod, setPaymentMethod] = useState<PaymentDetails['method']>('razorpay');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [paymentError, setPaymentError] = useState<string>('');

  if (!isOpen) return null;

  const currentShop = shops.find((s) => s.id === activeShopId) || shops[0];
  const itemTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const deliveryFee = itemTotal >= 99 ? 0 : 25;
  const handlingFee = 2;
  const grandTotal = itemTotal + deliveryFee + handlingFee + tip;

  // Cash on delivery: no online payment needed, order is placed as "pending" payment.
  const handlePlaceCodOrder = () => {
    setIsProcessing(true);
    setPaymentError('');
    setTimeout(() => {
      const order = placeOrder({ method: 'cod' }, tip);
      setIsProcessing(false);
      onClose();
      onOrderSuccess(order.id);
    }, 500);
  };

  // Real Razorpay flow: create a server-side order, open Razorpay Checkout,
  // and only place the order in our system after the backend verifies the
  // payment signature. Nothing here is marked "paid" without that verification.
  const handlePayWithRazorpay = async () => {
    setIsProcessing(true);
    setPaymentError('');
    try {
      const scriptLoaded = await loadRazorpayScript();
      if (!scriptLoaded) {
        throw new Error('Could not load the payment SDK. Check your internet connection.');
      }

      const createRes = await fetch('/api/payment/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: grandTotal,
          receipt: `order_${Date.now()}`
        })
      });

      if (!createRes.ok) {
        throw new Error('Could not start payment. Please try again.');
      }
      const { orderId, amount, currency, keyId } = await createRes.json();

      const razorpay = new window.Razorpay({
        key: keyId,
        amount,
        currency,
        order_id: orderId,
        name: currentShop.name || 'QuickBlink',
        description: `Order for ₹${grandTotal}`,
        prefill: {
          name: 'Sanket Patil',
          contact: '+919845199001'
        },
        theme: { color: '#0c831f' },
        handler: async (response: any) => {
          try {
            const verifyRes = await fetch('/api/payment/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature
              })
            });
            const { verified } = await verifyRes.json();

            if (!verified) {
              setPaymentError('Payment could not be verified. If money was deducted, it will be refunded automatically — please contact support.');
              setIsProcessing(false);
              return;
            }

            const order = placeOrder(
              {
                method: 'razorpay',
                transactionId: response.razorpay_payment_id
              },
              tip
            );
            setIsProcessing(false);
            onClose();
            onOrderSuccess(order.id);
          } catch (err) {
            console.error('Payment verification error:', err);
            setPaymentError('Something went wrong verifying your payment. Please contact support before retrying.');
            setIsProcessing(false);
          }
        },
        modal: {
          ondismiss: () => setIsProcessing(false)
        }
      });

      razorpay.on('payment.failed', (resp: any) => {
        console.warn('Razorpay payment failed:', resp?.error);
        setPaymentError(resp?.error?.description || 'Payment failed. Please try again.');
        setIsProcessing(false);
      });

      razorpay.open();
    } catch (err: any) {
      console.error('Razorpay init error:', err);
      setPaymentError(err?.message || 'Could not start payment. Please try again.');
      setIsProcessing(false);
    }
  };

  const handlePayAndOrder = () => {
    if (paymentMethod === 'cod') {
      handlePlaceCodOrder();
    } else {
      handlePayWithRazorpay();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-250">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <Zap className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-sm">Your Grocery Cart</h3>
              <p className="text-[11px] text-slate-500 font-medium">
                Delivering from {currentShop.name.slice(0, 24)}...
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-200 rounded-full text-slate-500 hover:text-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {cart.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
                <Trash2 className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-slate-800 text-base">Your Cart is Empty</h4>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Explore thousands of snacks, dairy, fresh vegetables and fruits delivered in 10 mins.
              </p>
            </div>
          ) : (
            <>
              {/* Delivery ETA Banner */}
              <div className="bg-emerald-50 border border-emerald-200/80 rounded-xl p-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
                  <span className="text-xs font-bold text-emerald-900">
                    Delivery in 8-12 Mins
                  </span>
                </div>
                <span className="text-[10px] font-extrabold text-emerald-700 uppercase tracking-wide bg-white px-2 py-0.5 rounded-full border border-emerald-200">
                  ⚡ Hyperlocal Kirana
                </span>
              </div>

              {/* Items List */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-xs font-bold text-slate-500 px-1">
                  <span>ITEMS ({cart.reduce((a, b) => a + b.quantity, 0)})</span>
                  <button
                    onClick={clearCart}
                    className="text-rose-600 hover:underline text-[11px]"
                  >
                    Clear All
                  </button>
                </div>

                <div className="divide-y divide-slate-100 bg-white border border-slate-100 rounded-2xl p-2 shadow-2xs">
                  {cart.map((item) => (
                    <div
                      key={item.product.id}
                      className="py-2.5 px-1 flex items-center justify-between gap-3"
                    >
                      <img
                        src={item.product.imageUrl}
                        alt={item.product.name}
                        className="w-12 h-12 object-contain rounded-lg bg-slate-50 p-1 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h5 className="font-bold text-slate-800 text-xs truncate">
                          {item.product.name}
                        </h5>
                        <p className="text-[11px] text-slate-400 font-medium">
                          {item.product.unit} • ₹{item.product.price}
                        </p>
                      </div>

                      {/* Stepper */}
                      <div className="flex items-center bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl overflow-hidden shrink-0">
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                          className="px-2 py-1 hover:bg-emerald-100"
                        >
                          <Minus className="w-3 h-3 stroke-[3]" />
                        </button>
                        <span className="px-2 text-xs font-black">{item.quantity}</span>
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                          className="px-2 py-1 hover:bg-emerald-100"
                        >
                          <Plus className="w-3 h-3 stroke-[3]" />
                        </button>
                      </div>

                      <span className="font-extrabold text-xs text-slate-900 w-12 text-right">
                        ₹{item.product.price * item.quantity}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Delivery Partner Tip */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-700">
                    Tip your Delivery Partner
                  </span>
                  <span className="text-[10px] text-emerald-600 font-bold">
                    100% goes to rider
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {[0, 10, 20, 30].map((amount) => (
                    <button
                      key={amount}
                      onClick={() => setTip(amount)}
                      className={`py-1.5 text-xs font-bold rounded-xl border transition-all ${
                        tip === amount
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {amount === 0 ? 'No Tip' : `₹${amount}`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Payment Method Selector */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">PAYMENT METHOD</span>
                  <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    Secured by Razorpay
                  </span>
                </div>

                <div className="space-y-2">
                  {/* Pay online via Razorpay */}
                  <div
                    onClick={() => setPaymentMethod('razorpay')}
                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                      paymentMethod === 'razorpay'
                        ? 'border-emerald-500 bg-emerald-50/50 shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="paymentMethod"
                        checked={paymentMethod === 'razorpay'}
                        onChange={() => setPaymentMethod('razorpay')}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-2xs">
                          <CreditCard className="w-4 h-4" />
                        </div>
                        <div>
                          <span className="text-xs font-bold text-slate-900 block">UPI / Card / Netbanking</span>
                          <span className="text-[10px] text-slate-400">Pay online — verified before order is placed</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Cash on delivery */}
                  <div
                    onClick={() => setPaymentMethod('cod')}
                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                      paymentMethod === 'cod'
                        ? 'border-amber-500 bg-amber-50/50 shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="paymentMethod"
                        checked={paymentMethod === 'cod'}
                        onChange={() => setPaymentMethod('cod')}
                        className="text-amber-600 focus:ring-amber-500"
                      />
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shadow-2xs">
                          <Banknote className="w-4 h-4" />
                        </div>
                        <div>
                          <span className="text-xs font-bold text-slate-900 block">Cash / UPI on Delivery</span>
                          <span className="text-[10px] text-slate-400">Pay the delivery partner at the doorstep</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {paymentError && (
                  <div className="flex items-start gap-2 p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-[11px] text-rose-700">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{paymentError}</span>
                  </div>
                )}
              </div>

              {/* Bill Details */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 space-y-2 text-xs">
                <div className="font-bold text-slate-700 border-b border-slate-200/80 pb-1.5">
                  Bill Details
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Item Total</span>
                  <span className="font-bold text-slate-800">₹{itemTotal}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Delivery Partner Fee</span>
                  {deliveryFee === 0 ? (
                    <span className="text-emerald-600 font-extrabold uppercase">FREE</span>
                  ) : (
                    <span className="font-bold text-slate-800">₹{deliveryFee}</span>
                  )}
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Platform & Handling Fee</span>
                  <span className="font-bold text-slate-800">₹{handlingFee}</span>
                </div>
                {tip > 0 && (
                  <div className="flex justify-between text-slate-600">
                    <span>Delivery Partner Tip</span>
                    <span className="font-bold text-slate-800">₹{tip}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-2 border-t border-slate-200">
                  <span>To Pay</span>
                  <span className="text-emerald-700">₹{grandTotal}</span>
                </div>
              </div>

              {/* Address Reminder */}
              <div className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-200 flex items-center gap-2">
                <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>
                  Delivering to: <strong className="text-slate-700">{selectedAddress.flatNo}, {selectedAddress.area}</strong>
                </span>
              </div>
            </>
          )}
        </div>

        {/* Bottom Sticky Action Bar */}
        {cart.length > 0 && (
          <div className="p-4 bg-white border-t border-slate-100 shadow-lg">
            <button
              id="btn-confirm-order"
              onClick={handlePayAndOrder}
              disabled={isProcessing}
              className="w-full py-3.5 px-4 text-white font-extrabold text-sm rounded-xl shadow-md flex items-center justify-between transition-all disabled:opacity-60 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800"
            >
              <div className="text-left">
                <span className="block text-xs font-normal opacity-90">Total: ₹{grandTotal}</span>
                <span className="font-black text-sm">
                  {paymentMethod === 'cod' ? 'Place COD Order' : `Pay ₹${grandTotal} Securely`}
                </span>
              </div>
              <div className="flex items-center gap-1">
                {isProcessing ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <span>{paymentMethod === 'cod' ? 'Confirm' : 'Pay Now'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </div>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
