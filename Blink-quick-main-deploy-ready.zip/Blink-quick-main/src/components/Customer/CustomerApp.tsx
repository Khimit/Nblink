import React, { useState, useMemo } from 'react';
import {
  Search,
  SlidersHorizontal,
  Store,
  Clock,
  Zap,
  ShoppingBag,
  ArrowRight,
  Sparkles,
  MapPin,
  ChevronRight,
  TrendingUp,
  Tag
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from './ProductCard';
import { CartDrawer } from './CartDrawer';
import { OrderTrackingModal } from './OrderTrackingModal';

const CATEGORIES = [
  'All',
  'Dairy & Bread',
  'Fresh Veggies',
  'Snacks & Munchies',
  'Instant Foods',
  'Drinks & Juices',
  'Daily Staples'
];

export const CustomerApp: React.FC = () => {
  const {
    products,
    shops,
    activeShopId,
    setActiveShopId,
    cart,
    orders,
    activeTrackingOrderId,
    setActiveTrackingOrderId,
    setRole
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isTrackingOpen, setIsTrackingOpen] = useState<boolean>(false);

  const currentShop = shops.find((s) => s.id === activeShopId) || shops[0];

  // Active in-flight order for live tracking bar
  const activeOrder = orders.find(
    (o) =>
      o.id === activeTrackingOrderId ||
      (o.status !== 'delivered' && o.status !== 'cancelled')
  );

  // Filter products by selected shop, category, and search query
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Allow products from current shop or default
      const matchesShop = p.shopId === currentShop.id || !p.shopId;
      const matchesCategory =
        selectedCategory === 'All' || p.category === selectedCategory;
      const matchesSearch =
        searchQuery.trim() === '' ||
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesShop && matchesCategory && matchesSearch;
    });
  }, [products, currentShop.id, selectedCategory, searchQuery]);

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalCartValue = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  return (
    <div className="pb-28">
      {/* Active Order Live Tracker Floating Header if an order is active */}
      {activeOrder && (
        <div className="sticky top-16 z-30 bg-gradient-to-r from-emerald-800 to-teal-900 text-white px-4 py-2.5 shadow-md flex items-center justify-between text-xs animate-in slide-in-from-top">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400"></span>
            </span>
            <div>
              <span className="font-extrabold block">
                Order #{activeOrder.orderNumber} is{' '}
                <span className="text-amber-300 uppercase">
                  {activeOrder.status.replace('_', ' ')}
                </span>
              </span>
              <span className="text-[10px] text-emerald-200">
                {activeOrder.status === 'delivered' ? 'Delivered successfully' : `ETA: ~${activeOrder.etaMinutes} mins • PIN: ${activeOrder.otp}`}
              </span>
            </div>
          </div>
          <button
            id="btn-track-live-order"
            onClick={() => setIsTrackingOpen(true)}
            className="px-3 py-1 bg-white text-emerald-900 font-black rounded-lg text-xs hover:bg-emerald-50 transition-colors flex items-center gap-1 shadow-xs"
          >
            <span>Track Live</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Partner Store Selector & Header Strip */}
      <div className="bg-white border-b border-slate-200/80 px-4 py-3">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Partner Kirana Store
                </span>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.2 rounded-md">
                  ★ {currentShop.rating}
                </span>
              </div>
              <h2 className="font-black text-slate-900 text-base flex items-center gap-1.5">
                {currentShop.name}
              </h2>
            </div>
          </div>

          {/* Switch Kirana Store Dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium hidden md:inline">
              Shop Nearby:
            </span>
            <select
              value={activeShopId}
              onChange={(e) => setActiveShopId(e.target.value)}
              className="px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {shops.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.distanceKm} km)
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Hero Banner Promo: 10 Min Grocery Delivery Guarantee */}
      <div className="max-w-7xl mx-auto px-4 pt-4">
        <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-emerald-700 via-green-600 to-emerald-800 text-white p-5 sm:p-6 shadow-md">
          <div className="max-w-lg space-y-1.5 relative z-10">
            <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur-md px-2.5 py-0.5 rounded-full text-[11px] font-black uppercase tracking-wider text-yellow-300">
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>Instant 10-Minute Delivery</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight leading-tight">
              India's Favorite Kiranas Delivered Straight to Doorstep
            </h1>
            <p className="text-xs text-emerald-100 font-medium">
              Packed fresh by your verified neighborhood storekeeper & delivered by our local rider fleet.
            </p>
          </div>
          {/* Subtle background graphics */}
          <div className="absolute -right-6 -bottom-6 w-36 h-36 bg-white/10 rounded-full blur-xl pointer-events-none" />
        </div>
      </div>

      {/* Sticky Search & Category Bar */}
      <div className="sticky top-16 sm:top-16 z-20 bg-slate-100/95 backdrop-blur-md py-3 px-4 border-b border-slate-200">
        <div className="max-w-7xl mx-auto space-y-2.5">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search milk, bread, chips, tomatoes, atta, drinks..."
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 hover:text-slate-700"
              >
                Clear
              </button>
            )}
          </div>

          {/* Categories Pill Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                    isSelected
                      ? 'bg-emerald-700 text-white shadow-xs scale-102'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Product Grid */}
      <main className="max-w-7xl mx-auto px-4 pt-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
              {selectedCategory === 'All' ? 'Everyday Essentials' : selectedCategory}
            </h3>
            <span className="text-xs text-slate-400 font-semibold">
              ({filteredProducts.length} items)
            </span>
          </div>

          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
            ⚡ 10 Mins ETA
          </span>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
            <p className="text-sm font-bold text-slate-700">No items match your query</p>
            <p className="text-xs text-slate-400 mt-1">
              Try searching for something else or switch categories.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </main>

      {/* Floating Bottom Cart Bar */}
      {totalCartCount > 0 && (
        <div className="fixed bottom-4 left-4 right-4 z-40 max-w-md mx-auto animate-in slide-in-from-bottom duration-200">
          <button
            id="btn-view-floating-cart"
            onClick={() => setIsCartOpen(true)}
            className="w-full bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white p-3.5 rounded-2xl shadow-xl flex items-center justify-between font-extrabold text-sm transition-all transform hover:scale-101"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center font-black">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <div className="text-left">
                <span className="block text-xs font-bold leading-tight">
                  {totalCartCount} {totalCartCount === 1 ? 'ITEM' : 'ITEMS'}
                </span>
                <span className="text-sm font-black">₹{totalCartValue}</span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 bg-white text-emerald-800 px-3 py-1.5 rounded-xl font-black text-xs shadow-xs">
              <span>View Cart</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </button>
        </div>
      )}

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onOrderSuccess={(orderId) => {
          setActiveTrackingOrderId(orderId);
          setIsTrackingOpen(true);
        }}
      />

      {/* Live Order Tracking Modal */}
      {isTrackingOpen && activeOrder && (
        <OrderTrackingModal
          order={activeOrder}
          onClose={() => setIsTrackingOpen(false)}
          onSwitchToShopkeeper={() => {
            setIsTrackingOpen(false);
            setRole('shopkeeper');
          }}
          onSwitchToRider={() => {
            setIsTrackingOpen(false);
            setRole('delivery');
          }}
        />
      )}
    </div>
  );
};
