import React from 'react';
import {
  X,
  Clock,
  MapPin,
  Phone,
  CheckCircle2,
  PackageCheck,
  Bike,
  Shield,
  Store,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { Order, OrderStatus } from '../../types';
import { LiveMap } from '../LiveMap';
import { LiveTrackingMap } from '../LiveTrackingMap';
import { useApp } from '../../context/AppContext';

interface OrderTrackingModalProps {
  order: Order;
  onClose: () => void;
  onSwitchToShopkeeper?: () => void;
  onSwitchToRider?: () => void;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  order,
  onClose,
  onSwitchToShopkeeper,
  onSwitchToRider
}) => {
  const { shops } = useApp();
  const originShop = shops.find((s) => s.id === order.shopId);

  const getStatusStep = (status: OrderStatus): number => {
    switch (status) {
      case 'placed':
        return 1;
      case 'accepted':
      case 'packing':
        return 2;
      case 'packed':
        return 3;
      case 'assigned':
      case 'picked_up':
      case 'out_for_delivery':
        return 4;
      case 'delivered':
        return 5;
      case 'cancelled':
        return 0;
      default:
        return 1;
    }
  };

  const currentStep = getStatusStep(order.status);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="p-4 bg-emerald-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-white/15 rounded-xl">
              <Clock className="w-4 h-4" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-sm sm:text-base tracking-tight">
                  {order.status === 'delivered'
                    ? 'Delivered Successfully! 🎉'
                    : `Arriving in ~${order.etaMinutes} Mins`}
                </h3>
                <span className="text-[10px] font-mono bg-emerald-900/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  {order.orderNumber}
                </span>
              </div>
              <p className="text-[11px] text-emerald-100 font-medium">
                {order.status === 'delivered'
                  ? 'Thank you for ordering with QuickBlink'
                  : 'Fast hyperlocal delivery from neighborhood kirana'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Interactive Live Route Map */}
          <LiveMap
            status={order.status}
            shopName={order.shopName}
            customerAddress={`${order.customerAddress.flatNo}, ${order.customerAddress.area}`}
            riderName={order.deliveryPartner?.name || 'Assigned Partner'}
            etaMinutes={order.etaMinutes}
          />

          {/* Real live GPS map — shows the actual delivery partner location */}
          {(order.status === 'picked_up' || order.status === 'out_for_delivery') && originShop && (
            <LiveTrackingMap
              shopLat={originShop.lat}
              shopLng={originShop.lng}
              shopName={originShop.name}
              customerLat={order.customerAddress.lat}
              customerLng={order.customerAddress.lng}
              customerLabel={`${order.customerAddress.flatNo}, ${order.customerAddress.area}`}
              riderLat={order.riderLocation?.lat}
              riderLng={order.riderLocation?.lng}
              riderName={order.deliveryPartner?.name}
            />
          )}

          {/* Delivery OTP Security Card (Essential Indian Delivery Feature) */}
          {order.status !== 'delivered' && (
            <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-dashed border-amber-300 rounded-2xl p-3.5 flex items-center justify-between shadow-xs">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-amber-950 flex items-center justify-center font-black shadow-xs">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wide block">
                    Your Delivery PIN / OTP
                  </span>
                  <span className="text-[10px] text-amber-700">
                    Share only with delivery partner at your door
                  </span>
                </div>
              </div>
              <div className="bg-white px-3 py-1.5 rounded-xl border border-amber-200 shadow-xs">
                <span className="text-xl font-black tracking-widest text-slate-900 font-mono">
                  {order.otp}
                </span>
              </div>
            </div>
          )}

          {/* 5-Step Visual Timeline */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
              Live Order Stages
            </h4>

            <div className="space-y-3">
              {[
                { step: 1, title: 'Order Placed & Paid', desc: `Verified via ${order.payment.method.toUpperCase()}` },
                { step: 2, title: 'Kirana Store Packing', desc: `${order.shopName} preparing fresh items` },
                { step: 3, title: 'Packed & Ready for Pickup', desc: 'Tamper-proof bag sealed' },
                { step: 4, title: 'Out for Delivery', desc: order.deliveryPartner ? `${order.deliveryPartner.name} on the way` : 'Rider arriving at store' },
                { step: 5, title: 'Delivered at Doorstep', desc: 'Verified with 4-digit PIN' }
              ].map((s) => {
                const isDone = currentStep > s.step;
                const isCurrent = currentStep === s.step;

                return (
                  <div key={s.step} className="flex items-start gap-3 relative">
                    <div className="flex flex-col items-center">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          isDone
                            ? 'bg-emerald-600 text-white'
                            : isCurrent
                            ? 'bg-amber-400 text-amber-950 ring-4 ring-amber-100 animate-pulse'
                            : 'bg-slate-200 text-slate-400'
                        }`}
                      >
                        {isDone ? <CheckCircle2 className="w-4 h-4" /> : s.step}
                      </div>
                      {s.step < 5 && (
                        <div
                          className={`w-0.5 h-6 my-0.5 ${
                            isDone ? 'bg-emerald-500' : 'bg-slate-200'
                          }`}
                        />
                      )}
                    </div>
                    <div className="flex-1 pb-1">
                      <div className="flex items-center justify-between">
                        <span
                          className={`text-xs font-bold ${
                            isCurrent
                              ? 'text-slate-900 font-extrabold'
                              : isDone
                              ? 'text-emerald-800'
                              : 'text-slate-400'
                          }`}
                        >
                          {s.title}
                        </span>
                        {isCurrent && (
                          <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded-md">
                            Active
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500">{s.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Simulation Shortcut Helpers */}
          {order.status !== 'delivered' && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs">
              <span className="text-emerald-900 font-semibold flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                Want to test the other perspectives?
              </span>
              <div className="flex items-center gap-1.5">
                {currentStep <= 3 && onSwitchToShopkeeper && (
                  <button
                    onClick={onSwitchToShopkeeper}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-100 border border-emerald-300 text-emerald-800 rounded-lg font-bold text-[11px]"
                  >
                    Pack as Storekeeper ➔
                  </button>
                )}
                {currentStep >= 3 && onSwitchToRider && (
                  <button
                    onClick={onSwitchToRider}
                    className="px-2.5 py-1 bg-white hover:bg-emerald-100 border border-emerald-300 text-emerald-800 rounded-lg font-bold text-[11px]"
                  >
                    Pickup as Rider ➔
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Delivery Partner Contact Card */}
          {order.deliveryPartner && (
            <div className="p-3.5 bg-white border border-slate-200 rounded-2xl flex items-center justify-between shadow-2xs">
              <div className="flex items-center gap-3">
                <img
                  src={order.deliveryPartner.photo}
                  alt={order.deliveryPartner.name}
                  className="w-11 h-11 rounded-full object-cover border border-emerald-500 shadow-xs"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-900">
                      {order.deliveryPartner.name}
                    </span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded-md">
                      ★ {order.deliveryPartner.rating}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {order.deliveryPartner.vehicle} • {order.deliveryPartner.vehicleNumber}
                  </p>
                </div>
              </div>

              <a
                href={`tel:${order.deliveryPartner.phone}`}
                className="p-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl border border-emerald-200 transition-colors"
                title="Call Delivery Boy"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          )}

          {/* Shopkeeper Details */}
          <div className="p-3.5 bg-white border border-slate-200 rounded-2xl flex items-center justify-between shadow-2xs text-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
                <Store className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-slate-900 block">{order.shopName}</span>
                <span className="text-[11px] text-slate-400 block truncate max-w-[220px]">
                  {order.shopAddress}
                </span>
              </div>
            </div>
            <a
              href={`tel:${order.shopPhone}`}
              className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-colors"
              title="Call Storekeeper"
            >
              <Phone className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Ordered Items Summary */}
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 space-y-2 text-xs">
            <div className="font-bold text-slate-700 border-b border-slate-200 pb-1.5 flex justify-between">
              <span>Items in this Order ({order.items.length})</span>
              <span>Total: ₹{order.bill.grandTotal}</span>
            </div>
            {order.items.map((item) => (
              <div key={item.productId} className="flex items-center justify-between text-slate-600">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-800">{item.quantity}x</span>
                  <span>{item.name} ({item.unit})</span>
                </div>
                <span className="font-semibold text-slate-800">₹{item.price * item.quantity}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-colors"
          >
            Close Tracking
          </button>
        </div>
      </div>
    </div>
  );
};
