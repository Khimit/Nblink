import React from 'react';
import { Plus, Minus } from 'lucide-react';
import { Product } from '../../types';
import { useApp } from '../../context/AppContext';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { cart, addToCart, updateCartQuantity } = useApp();

  const cartItem = cart.find((item) => item.product.id === product.id);
  const quantity = cartItem ? cartItem.quantity : 0;

  return (
    <div className="bg-white rounded-2xl p-3 border border-slate-100 hover:border-slate-200 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group relative overflow-hidden">
      {/* Discount Badge */}
      {product.discountPercent > 0 && (
        <span className="absolute top-2.5 left-2.5 z-10 bg-emerald-700 text-white font-black text-[10px] px-1.5 py-0.5 rounded-md tracking-wider shadow-xs">
          {product.discountPercent}% OFF
        </span>
      )}

      {/* Image Container */}
      <div className="relative w-full aspect-square rounded-xl bg-slate-50 overflow-hidden flex items-center justify-center p-2 mb-2">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-full object-contain mix-blend-multiply group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        {!product.inStock && (
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center">
            <span className="bg-rose-600 text-white font-bold text-xs px-2.5 py-1 rounded-full uppercase tracking-wider">
              Out of Stock
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col justify-between">
        <div>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            {product.brand}
          </span>
          <h4 className="font-bold text-slate-800 text-xs sm:text-sm line-clamp-2 leading-snug min-h-[2.5rem]">
            {product.name}
          </h4>
          <span className="inline-block mt-1 text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
            {product.unit}
          </span>
        </div>

        {/* Pricing & Add Stepper */}
        <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-100">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-sm sm:text-base font-extrabold text-slate-900">
                ₹{product.price}
              </span>
              {product.mrp > product.price && (
                <span className="text-[11px] text-slate-400 line-through">
                  ₹{product.mrp}
                </span>
              )}
            </div>
          </div>

          {/* Add / Stepper Button */}
          {product.inStock ? (
            quantity === 0 ? (
              <button
                id={`btn-add-product-${product.id}`}
                onClick={() => addToCart(product)}
                className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white border border-emerald-300 hover:border-emerald-600 rounded-xl text-xs font-black transition-all flex items-center gap-1 shadow-2xs hover:shadow-xs active:scale-95"
              >
                <span>ADD</span>
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
              </button>
            ) : (
              <div className="flex items-center bg-emerald-600 text-white rounded-xl shadow-xs overflow-hidden">
                <button
                  id={`btn-minus-product-${product.id}`}
                  onClick={() => updateCartQuantity(product.id, quantity - 1)}
                  className="px-2 py-1.5 hover:bg-emerald-700 active:bg-emerald-800 transition-colors"
                >
                  <Minus className="w-3 h-3 stroke-[3]" />
                </button>
                <span className="px-2 text-xs font-extrabold select-none">
                  {quantity}
                </span>
                <button
                  id={`btn-plus-product-${product.id}`}
                  onClick={() => updateCartQuantity(product.id, quantity + 1)}
                  className="px-2 py-1.5 hover:bg-emerald-700 active:bg-emerald-800 transition-colors"
                >
                  <Plus className="w-3 h-3 stroke-[3]" />
                </button>
              </div>
            )
          ) : (
            <span className="text-[10px] font-bold text-slate-400">Unavailable</span>
          )}
        </div>
      </div>
    </div>
  );
};
