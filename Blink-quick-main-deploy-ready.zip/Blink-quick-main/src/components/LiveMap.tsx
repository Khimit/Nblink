import React from 'react';
import {
  PackageCheck,
  CheckCircle2,
  Clock,
  Store,
  Home,
  Bike,
  Package,
  Sparkles
} from 'lucide-react';
import { OrderStatus } from '../types';

interface LiveMapProps {
  status: OrderStatus;
  shopName: string;
  customerAddress: string;
  riderName?: string;
  etaMinutes: number;
}

export const LiveMap: React.FC<LiveMapProps> = ({
  status,
  shopName,
  customerAddress,
  riderName = 'Assigned Partner',
  etaMinutes
}) => {
  // Step mapping:
  // 1: placed / accepted
  // 2: packing
  // 3: packed
  // 4: assigned / picked_up / out_for_delivery
  // 5: delivered
  const getStepNumber = (): number => {
    switch (status) {
      case 'placed':
      case 'accepted':
        return 1;
      case 'packing':
        return 2;
      case 'packed':
        return 3;
      case 'assigned':
      case 'picked_up':
      case 'out_for_delivery':
        return 4;
      case 'delivered':
        return 5;
      case 'cancelled':
        return 0;
      default:
        return 1;
    }
  };

  const currentStep = getStepNumber();

  const stages = [
    {
      step: 1,
      title: 'Order Placed',
      label: 'Confirmed',
      desc: 'Payment received via UPI',
      icon: Clock
    },
    {
      step: 2,
      title: 'Packing',
      label: 'Store Packing',
      desc: `${shopName} picking items`,
      icon: Store
    },
    {
      step: 3,
      title: 'Packed',
      label: 'Ready for Pickup',
      desc: 'Bag sealed with tamper tag',
      icon: PackageCheck
    },
    {
      step: 4,
      title: 'Out for Delivery',
      label: 'On the Way',
      desc: `${riderName} en route to doorstep`,
      icon: Bike
    },
    {
      step: 5,
      title: 'Delivered',
      label: 'Delivered 🎉',
      desc: 'Order handed over with PIN',
      icon: CheckCircle2
    }
  ];

  const getStatusBadge = () => {
    switch (status) {
      case 'packing':
        return { text: 'Kirana Store Packing Fresh Items', color: 'bg-amber-100 text-amber-900 border-amber-300' };
      case 'packed':
        return { text: 'Order Packed & Sealed in Bag', color: 'bg-blue-100 text-blue-900 border-blue-300' };
      case 'out_for_delivery':
      case 'picked_up':
      case 'assigned':
        return { text: `Out for Delivery • ~${etaMinutes} Mins`, color: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      case 'delivered':
        return { text: 'Order Delivered Successfully!', color: 'bg-emerald-600 text-white border-emerald-700' };
      default:
        return { text: 'Order Confirmed & Sent to Store', color: 'bg-slate-100 text-slate-800 border-slate-300' };
    }
  };

  const currentBadge = getStatusBadge();

  return (
    <div className="w-full rounded-2xl bg-white border border-slate-200 shadow-sm p-4 space-y-4">
      {/* Top Status Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-600"></span>
          </span>
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">Live Status</div>
            <div className="text-sm font-black text-slate-900">
              {stages.find((s) => s.step === currentStep)?.label || 'Processing'}
            </div>
          </div>
        </div>

        <div className={`text-xs font-bold px-3 py-1 rounded-full border self-start sm:self-auto ${currentBadge.color}`}>
          {currentBadge.text}
        </div>
      </div>

      {/* Horizontal Status Progress Bar */}
      <div className="relative pt-2 pb-1">
        {/* Progress line */}
        <div className="absolute top-6 left-6 right-6 h-1 bg-slate-100 -z-0">
          <div
            className="h-full bg-emerald-600 transition-all duration-500"
            style={{
              width: `${Math.min(Math.max(((currentStep - 1) / 4) * 100, 0), 100)}%`
            }}
          />
        </div>

        {/* 5 Step Nodes */}
        <div className="flex justify-between relative z-10">
          {stages.map((st) => {
            const isCompleted = currentStep >= st.step;
            const isCurrent = currentStep === st.step;
            const Icon = st.icon;

            return (
              <div key={st.step} className="flex flex-col items-center text-center max-w-[68px]">
                <div
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
                    isCompleted
                      ? 'bg-emerald-600 text-white shadow-sm ring-4 ring-emerald-100'
                      : 'bg-slate-100 text-slate-400 border border-slate-200'
                  } ${isCurrent ? 'ring-emerald-200 scale-110' : ''}`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <span
                  className={`text-[11px] mt-2 font-bold leading-tight ${
                    isCurrent ? 'text-emerald-700' : isCompleted ? 'text-slate-800' : 'text-slate-400'
                  }`}
                >
                  {st.title}
                </span>
                <span className="text-[9px] text-slate-400 font-medium hidden sm:block mt-0.5">
                  {st.step === 2 ? 'Store' : st.step === 3 ? 'Sealed' : st.step === 4 ? 'Rider' : ''}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Origin Kirana & Doorstep Destination Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1 text-xs">
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 flex items-start gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
            <Store className="w-3.5 h-3.5" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] font-bold text-slate-500 uppercase block">Store Origin</span>
            <span className="font-bold text-slate-800 truncate block text-xs">{shopName}</span>
          </div>
        </div>

        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 flex items-start gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
            <Home className="w-3.5 h-3.5" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] font-bold text-slate-500 uppercase block">Delivery Doorstep</span>
            <span className="font-bold text-slate-800 truncate block text-xs">{customerAddress}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
