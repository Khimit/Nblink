import React, { useState } from 'react';
import {
  X,
  Smartphone,
  CheckCircle2,
  Download,
  Copy,
  Check,
  ShieldCheck,
  ExternalLink,
  Sparkles
} from 'lucide-react';

interface PlayStoreModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PlayStoreModal: React.FC<PlayStoreModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState<string | null>(null);

  if (!isOpen) return null;

  const gradleCommand = `cd android\n./gradlew assembleDebug\n# Generates: android/app/build/outputs/apk/debug/app-debug.apk`;
  const bubblewrapCommand = `npm i -g @bubblewrap/cli\nbubblewrap init --manifest=./public/manifest.json\nbubblewrap build`;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-60 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl animate-in zoom-in-95 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-slate-900 text-base">
                Android APK & Play Store Package
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                com.quickblink.delivery ready for Android installation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Instant WebAPK on Android without compiling */}
        <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl p-4 border border-emerald-200 space-y-2 text-xs">
          <div className="font-black text-emerald-950 flex items-center gap-1.5 text-[13px]">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span>Method 1: Instant APK on Your Phone (Google WebAPK)</span>
          </div>
          <p className="text-emerald-900 text-[11.5px] leading-relaxed">
            Google Chrome on Android automatically compiles and installs a genuine <strong>Android WebAPK</strong> directly on your phone:
          </p>
          <ol className="list-decimal list-inside text-[11.5px] text-emerald-800 space-y-1 font-medium">
            <li>Open the shared URL in <strong>Chrome on your Android phone</strong>.</li>
            <li>Tap the <strong>3 dots (⋮)</strong> menu at the top right of Chrome.</li>
            <li>Tap <strong>"Install App"</strong> or <strong>"Add to Home screen"</strong>.</li>
            <li>Android's Play Services will compile and install <strong>QuickBlink</strong> as a native Android APK in your App Drawer!</li>
          </ol>
        </div>

        {/* Native Android Studio / Gradle Project */}
        <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-black text-slate-900 text-[13px]">
              Method 2: Native Android Project (`/android`)
            </span>
            <button
              onClick={() => copyToClipboard(gradleCommand, 'gradle')}
              className="text-emerald-700 font-bold hover:underline flex items-center gap-1"
            >
              {copied === 'gradle' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied === 'gradle' ? 'Copied' : 'Copy Command'}</span>
            </button>
          </div>
          <p className="text-slate-600 text-[11.5px]">
            The complete native Android project has been generated in <code>/android</code>. Click the top-right AI Studio menu &gt; <strong>Export to ZIP</strong>:
          </p>
          <pre className="p-3 bg-slate-900 text-emerald-400 rounded-xl font-mono text-[11px] overflow-x-auto">
            {gradleCommand}
          </pre>
          <p className="text-[11px] text-slate-500">
            You can also open the <code>/android</code> folder in <strong>Android Studio</strong> and click <strong>Build &gt; Build APK(s)</strong>.
          </p>
        </div>

        {/* Packaging Options */}
        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-800">
              Method 3: Google Play Store AAB (Bubblewrap)
            </span>
            <button
              onClick={() => copyToClipboard(bubblewrapCommand, 'bubblewrap')}
              className="text-emerald-700 font-bold hover:underline flex items-center gap-1"
            >
              {copied === 'bubblewrap' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied === 'bubblewrap' ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <pre className="p-3 bg-slate-900 text-emerald-400 rounded-xl font-mono text-[11px] overflow-x-auto">
            {bubblewrapCommand}
          </pre>
        </div>

        <div className="pt-2">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
