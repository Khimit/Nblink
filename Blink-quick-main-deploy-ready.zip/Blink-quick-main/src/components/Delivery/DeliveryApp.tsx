import React, { useState, useEffect, useRef } from 'react';
import {
  Bike,
  Navigation,
  CheckCircle2,
  Phone,
  MapPin,
  Clock,
  ShieldAlert,
  KeyRound,
  ArrowRight,
  TrendingUp,
  AlertTriangle,
  Store,
  Home,
  Check,
  Zap,
  Volume2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { LiveMap } from '../LiveMap';
import { LiveTrackingMap } from '../LiveTrackingMap';

export const DeliveryApp: React.FC = () => {
  const {
    riders,
    activeRiderId,
    setActiveRiderId,
    orders,
    shops,
    acceptDeliveryTask,
    confirmPickup,
    verifyAndDeliver,
    toggleRiderDuty,
    updateRiderLocation,
    setRole
  } = useApp();

  const [otpInput, setOtpInput] = useState<string>('');
  const [otpError, setOtpError] = useState<string>('');
  const [deliverySuccessMessage, setDeliverySuccessMessage] = useState<string>('');
  const [locationError, setLocationError] = useState<string>('');
  const watchIdRef = useRef<number | null>(null);

  const currentRider = riders.find((r) => r.id === activeRiderId) || riders[0];

  // Orders available for pickup (status === 'packed' or 'placed' or 'packing')
  const availableOrders = orders.filter(
    (o) => (o.status === 'packed' || o.status === 'packing') && (!o.deliveryPartner || o.deliveryPartner.id === currentRider.id)
  );

  // Active in-progress order assigned to this rider
  const activeOrder = orders.find(
    (o) =>
      o.deliveryPartner?.id === currentRider.id &&
      (o.status === 'assigned' || o.status === 'picked_up' || o.status === 'out_for_delivery')
  );

  const completedOrders = orders.filter(
    (o) => o.deliveryPartner?.id === currentRider.id && o.status === 'delivered'
  );

  // Broadcast this rider's real GPS position while actively delivering an
  // order, so the customer's live map (and admin fleet view) update in
  // real time. Stops automatically once the order is no longer active.
  useEffect(() => {
    const shouldTrack =
      activeOrder && (activeOrder.status === 'picked_up' || activeOrder.status === 'out_for_delivery');

    if (!shouldTrack) {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      return;
    }

    if (!navigator.geolocation) {
      setLocationError('Live location isn\'t supported on this device/browser.');
      return;
    }

    const orderId = activeOrder.id;
    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        setLocationError('');
        updateRiderLocation(orderId, position.coords.latitude, position.coords.longitude);
      },
      (err) => {
        console.warn('Geolocation error:', err);
        setLocationError('Location permission needed to share your live position with the customer.');
      },
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 }
    );

    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeOrder?.id, activeOrder?.status]);

  const handleDeliverSubmit = (orderId: string) => {
    if (!otpInput.trim()) {
      setOtpError('Please enter the 4-digit Delivery PIN from the customer.');
      return;
    }

    const result = verifyAndDeliver(orderId, otpInput);
    if (!result.success) {
      setOtpError(result.message);
    } else {
      setOtpError('');
      setOtpInput('');
      setDeliverySuccessMessage(result.message);
      setTimeout(() => setDeliverySuccessMessage(''), 5000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-5">
      {/* Rider Header Profile Card */}
      <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative">
              <img
                src={currentRider.photo}
                alt={currentRider.name}
                className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500 shadow-md"
              />
              <span
                className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-slate-900 ${
                  currentRider.isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-slate-500'
                }`}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-tight">{currentRider.name}</h2>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-black px-2 py-0.5 rounded-full">
                  ★ {currentRider.rating}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {currentRider.vehicle} • <strong className="text-slate-200">{currentRider.vehicleNumber}</strong>
              </p>
            </div>
          </div>

          {/* Online / Offline Switch */}
          <div className="flex items-center gap-2">
            <select
              value={activeRiderId}
              onChange={(e) => setActiveRiderId(e.target.value)}
              className="bg-slate-800 text-slate-200 border border-slate-700 text-xs font-bold rounded-xl px-3 py-2"
            >
              {riders.map((r) => (
                <option key={r.id} value={r.id}>
                  Rider: {r.name}
                </option>
              ))}
            </select>

            <button
              id="btn-toggle-rider-duty"
              onClick={() => toggleRiderDuty(currentRider.id)}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${
                currentRider.isOnline
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-900/30 shadow-md'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-400'
              }`}
            >
              <Bike className="w-4 h-4" />
              <span>{currentRider.isOnline ? 'ON DUTY (Ready)' : 'OFFLINE'}</span>
            </button>
          </div>
        </div>

        {/* Earning Stats */}
        <div className="grid grid-cols-3 gap-3 mt-5 pt-5 border-t border-slate-800 text-center">
          <div className="bg-slate-800/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Today's Earnings</span>
            <div className="text-xl font-black text-emerald-400 mt-0.5">
              ₹{currentRider.todayEarnings}
            </div>
          </div>
          <div className="bg-slate-800/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Completed Deliveries</span>
            <div className="text-xl font-black text-slate-200 mt-0.5">
              {currentRider.completedDeliveries}
            </div>
          </div>
          <div className="bg-slate-800/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Per Order Rate</span>
            <div className="text-xl font-black text-amber-400 mt-0.5">
              ₹45 + Tip
            </div>
          </div>
        </div>
      </div>

      {/* Success Notification Alert */}
      {deliverySuccessMessage && (
        <div className="bg-emerald-600 text-white p-4 rounded-2xl shadow-lg flex items-center justify-between text-xs font-bold animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-white" />
            <span>{deliverySuccessMessage}</span>
          </div>
          <button
            onClick={() => setDeliverySuccessMessage('')}
            className="text-white/80 hover:text-white"
          >
            ✕
          </button>
        </div>
      )}

      {/* 1. ACTIVE ORDER IN PROGRESS (Priority view for Rider) */}
      {activeOrder && (
        <div className="bg-white rounded-3xl p-5 sm:p-6 border-2 border-emerald-500 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-600"></span>
              </span>
              <h3 className="font-black text-slate-900 text-base sm:text-lg">
                Active Delivery Task #{activeOrder.orderNumber}
              </h3>
            </div>
            <span className="bg-emerald-100 text-emerald-800 font-extrabold text-xs px-2.5 py-1 rounded-full uppercase">
              Earning: ₹{45 + (activeOrder.bill.tip || 0)}
            </span>
          </div>

          {/* Interactive Live Route Map */}
          <LiveMap
            status={activeOrder.status}
            shopName={activeOrder.shopName}
            customerAddress={`${activeOrder.customerAddress.flatNo}, ${activeOrder.customerAddress.area}`}
            riderName={currentRider.name}
            etaMinutes={activeOrder.etaMinutes}
          />

          {/* Real live GPS map — shares your actual device location with the customer */}
          {(activeOrder.status === 'picked_up' || activeOrder.status === 'out_for_delivery') && (
            <>
              {locationError ? (
                <div className="text-xs font-bold text-amber-800 bg-amber-50 border border-amber-200 rounded-xl p-2.5">
                  ⚠️ {locationError} Enable location access in your browser to share live tracking.
                </div>
              ) : (
                (() => {
                  const originShop = shops.find((s) => s.id === activeOrder.shopId);
                  if (!originShop) return null;
                  return (
                    <LiveTrackingMap
                      shopLat={originShop.lat}
                      shopLng={originShop.lng}
                      shopName={originShop.name}
                      customerLat={activeOrder.customerAddress.lat}
                      customerLng={activeOrder.customerAddress.lng}
                      customerLabel={`${activeOrder.customerAddress.flatNo}, ${activeOrder.customerAddress.area}`}
                      riderLat={activeOrder.riderLocation?.lat}
                      riderLng={activeOrder.riderLocation?.lng}
                      riderName={currentRider.name}
                    />
                  );
                })()
              )}
            </>
          )}

          {/* Pickup & Drop Points Accordion */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* Store Pickup */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-slate-500 uppercase text-[10px] flex items-center gap-1">
                  <Store className="w-3.5 h-3.5 text-emerald-600" />
                  Step 1: Pick from Shop
                </span>
                <a
                  href={`tel:${activeOrder.shopPhone}`}
                  className="text-emerald-700 font-bold hover:underline flex items-center gap-1"
                >
                  <Phone className="w-3 h-3" /> Call Shop
                </a>
              </div>
              <div className="font-bold text-slate-900 text-sm">{activeOrder.shopName}</div>
              <p className="text-slate-500 text-[11px]">{activeOrder.shopAddress}</p>
            </div>

            {/* Customer Drop */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-slate-500 uppercase text-[10px] flex items-center gap-1">
                  <Home className="w-3.5 h-3.5 text-blue-600" />
                  Step 2: Deliver to Customer
                </span>
                <a
                  href={`tel:${activeOrder.customerPhone}`}
                  className="text-blue-700 font-bold hover:underline flex items-center gap-1"
                >
                  <Phone className="w-3 h-3" /> Call Customer
                </a>
              </div>
              <div className="font-bold text-slate-900 text-sm">{activeOrder.customerName}</div>
              <p className="text-slate-500 text-[11px]">
                {activeOrder.customerAddress.flatNo}, {activeOrder.customerAddress.street}, {activeOrder.customerAddress.landmark}
              </p>
            </div>
          </div>

          {/* Items to verify in bag */}
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 text-xs">
            <span className="font-bold text-slate-700 block mb-1">
              Bag Contents ({activeOrder.items.length} items):
            </span>
            <div className="text-slate-600 flex flex-wrap gap-2">
              {activeOrder.items.map((i) => (
                <span key={i.productId} className="bg-white px-2 py-0.5 rounded-md border border-slate-200 font-medium">
                  {i.quantity}x {i.name}
                </span>
              ))}
            </div>
          </div>

          {/* RIDER TASK ACTIONS BASED ON CURRENT STAGE */}
          <div className="pt-2">
            {activeOrder.status === 'assigned' && (
              <button
                id="btn-confirm-pickup-at-store"
                onClick={() => confirmPickup(activeOrder.id)}
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm rounded-2xl shadow-md flex items-center justify-center gap-2 transition-all"
              >
                <Check className="w-5 h-5 stroke-[3]" />
                <span>At Shop: Bag Collected & Start Delivery ➔</span>
              </button>
            )}

            {(activeOrder.status === 'picked_up' || activeOrder.status === 'out_for_delivery') && (
              <div className="bg-amber-50/70 border-2 border-amber-300 rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <KeyRound className="w-5 h-5 text-amber-700" />
                  <div>
                    <h4 className="font-black text-slate-900 text-xs sm:text-sm">
                      Doorstep Delivery PIN Verification
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      Ask customer for their 4-digit PIN (shown on their live screen) to confirm handover.
                    </p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    maxLength={4}
                    value={otpInput}
                    onChange={(e) => setOtpInput(e.target.value)}
                    placeholder="Enter 4-digit PIN"
                    className="w-40 px-3 py-2 bg-white border border-amber-300 rounded-xl font-mono text-center text-base font-black tracking-widest text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <button
                    id="btn-verify-otp-deliver"
                    onClick={() => handleDeliverSubmit(activeOrder.id)}
                    className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md transition-colors flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Verify PIN & Complete Delivery</span>
                  </button>
                </div>

                {otpError && (
                  <p className="text-xs font-bold text-rose-600 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {otpError}
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. AVAILABLE PICKUP TASKS NEARBY */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-slate-900 text-base">
              Available Delivery Tasks
            </h3>
            <span className="bg-emerald-100 text-emerald-800 text-xs font-black px-2 py-0.5 rounded-full">
              {availableOrders.length} Nearby
            </span>
          </div>
          <span className="text-xs text-slate-400 font-semibold">10-Min Hyperlocal Radius</span>
        </div>

        {availableOrders.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200">
            <Clock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-700">No pending pickup requests right now</p>
            <p className="text-xs text-slate-400 mt-0.5">
              When a kirana shop packs an order, it will alert you here instantly with sound.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {availableOrders.map((order) => (
              <div
                key={order.id}
                className="bg-white rounded-3xl p-5 border border-slate-200 hover:border-emerald-500 shadow-xs hover:shadow-md transition-all space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-black text-xs text-slate-900">
                      #{order.orderNumber}
                    </span>
                    <span className="bg-purple-100 text-purple-900 text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase">
                      {order.status === 'packed' ? 'Packed & Ready' : 'In-Packing'}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-black text-emerald-700">
                      ₹{45 + (order.bill.tip || 0)}
                    </span>
                    <span className="text-[10px] text-slate-400 block font-medium">
                      Earning (Base + Tip)
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-400 font-bold block uppercase">Pickup</span>
                    <span className="font-bold text-slate-800 truncate block">{order.shopName}</span>
                    <span className="text-[10px] text-slate-500">0.8 km away</span>
                  </div>
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-400 font-bold block uppercase">Drop</span>
                    <span className="font-bold text-slate-800 truncate block">{order.customerName}</span>
                    <span className="text-[10px] text-slate-500">{order.customerAddress.area}</span>
                  </div>
                </div>

                <button
                  id={`btn-accept-task-${order.id}`}
                  onClick={() => acceptDeliveryTask(order.id, currentRider.id)}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <Bike className="w-4 h-4" />
                  <span>Accept Delivery Task (₹{45 + (order.bill.tip || 0)})</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 3. COMPLETED TRIPS TODAY */}
      {completedOrders.length > 0 && (
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
          <h4 className="font-extrabold text-slate-900 text-sm">
            Completed Deliveries Today ({completedOrders.length})
          </h4>
          <div className="divide-y divide-slate-100 text-xs">
            {completedOrders.map((ord) => (
              <div key={ord.id} className="py-2.5 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-800 block">
                    #{ord.orderNumber} • {ord.customerName}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    From {ord.shopName}
                  </span>
                </div>
                <span className="font-black text-emerald-700">
                  +₹{45 + (ord.bill.tip || 0)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
