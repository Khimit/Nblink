package com.quickblink.delivery;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
