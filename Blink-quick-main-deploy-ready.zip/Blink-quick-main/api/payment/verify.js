// Vercel serverless function — same logic as server.js's verify route,
// deployed automatically at /api/payment/verify when hosted on Vercel.
import crypto from 'crypto';

export default function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({ verified: false, error: 'Missing fields' });
  }

  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  const verified = expectedSignature === razorpay_signature;
  if (!verified) {
    console.warn('Payment signature mismatch — possible tampering attempt:', {
      razorpay_order_id,
      razorpay_payment_id
    });
  }

  res.status(200).json({ verified });
}
